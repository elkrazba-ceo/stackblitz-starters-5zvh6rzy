export type RocketPhase = 'idle' | 'countdown' | 'ignition' | 'flight' | 'success';
export type LaunchState = { index: number; phase: RocketPhase; phaseStartedAt: number; updatedAt: number };
export const initialLaunchState: LaunchState = { index: 0, phase: 'idle', phaseStartedAt: 0, updatedAt: 0 };
const channelName = 'safarone-launch-presentation-v1';
const fallbackKey = 'safarone-launch-sync-v1';

export function openLaunchChannel(onMessage?: (state: LaunchState) => void) {
  let channel: BroadcastChannel | null = null;
  if (typeof BroadcastChannel !== 'undefined') {
    channel = new BroadcastChannel(channelName);
    if (onMessage) channel.onmessage = (event: MessageEvent<LaunchState>) => {
      if (event.data && typeof event.data.index === 'number') onMessage(event.data);
    };
  }
  const storageHandler = (event: StorageEvent) => {
    if (event.key !== fallbackKey || !event.newValue || !onMessage) return;
    try { onMessage(JSON.parse(event.newValue) as LaunchState); } catch { /* ignore malformed fallback data */ }
  };
  if (onMessage) {
    window.addEventListener('storage', storageHandler);
    try {
      const saved = localStorage.getItem(fallbackKey);
      if (saved) {
        const parsed = JSON.parse(saved) as LaunchState;
        if (parsed && typeof parsed.index === 'number') onMessage(parsed);
      }
    } catch { /* no stored sync state */ }
  }
  return {
    post(state: LaunchState) {
      channel?.postMessage(state);
      try { localStorage.setItem(fallbackKey, JSON.stringify(state)); } catch { /* storage can be disabled */ }
    },
    close() {
      channel?.close();
      window.removeEventListener('storage', storageHandler);
    },
  };
}
