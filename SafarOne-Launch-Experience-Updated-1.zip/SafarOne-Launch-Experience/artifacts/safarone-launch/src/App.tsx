import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { LaunchPresentation } from '@/components/LaunchPresentation';
import { openLaunchChannel, type LaunchState, initialLaunchState } from '@/lib/launch-sync';

const PresenterConsole = lazy(() => import('@/pages/PresenterConsole'));
const queryClient = new QueryClient();

function Home() {
  const mode = new URLSearchParams(window.location.search).get('mode');
  const isPresenter = mode === 'presenter';
  const [state, setState] = useState<LaunchState>(initialLaunchState);
  const channelRef = useRef<ReturnType<typeof openLaunchChannel> | null>(null);

  useEffect(() => {
    const channel = openLaunchChannel((next) => setState(next));
    channelRef.current = channel;
    return () => channel.close();
  }, []);

  const update = useCallback((patch: Partial<LaunchState>) => {
    setState((current) => {
      const next = { ...current, ...patch, updatedAt: Date.now() };
      channelRef.current?.post(next);
      return next;
    });
  }, []);
  return (
    <div className="launch-app">
      {isPresenter ? (
        <Suspense fallback={<div className="presenter-shell"><div className="presenter-main"><div className="presenter-preview" /></div></div>}>
          <PresenterConsole state={state} update={update} />
        </Suspense>
      ) : (
        <LaunchPresentation state={state} update={update} />
      )}
    </div>
  );
}

function Router() {
  return <ErrorBoundary resetKey={window.location.pathname}><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
