import { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Expand, List, Volume2, VolumeX, X, RotateCcw } from 'lucide-react';
import { slides, sourceLinks, type PresentationSlide } from '@/data/slides';
import { ImmersiveScene } from '@/components/ImmersiveScene';
import { RocketScene } from '@/components/RocketScene';
import type { LaunchState, RocketPhase } from '@/lib/launch-sync';

type Props = { state: LaunchState; update: (patch: Partial<LaunchState>) => void };

function ItemGrid({ slide }: { slide: PresentationSlide }) {
  if (!slide.items?.length) return null;
  return <div className="items-grid">{slide.items.map((item, index) => <article className="item-card" key={`${item.title}-${index}`}><h3>{item.title}</h3><p>{item.body}</p></article>)}</div>;
}

function AnimatedCounter({ value }: { value: string }) {
  const match = value.match(/^(\+?)([\d\s,.]+)(.*)$/);
  const prefix = match?.[1] ?? '';
  const numberText = match?.[2] ?? value;
  const suffix = match?.[3] ?? '';
  const target = Number(numberText.replace(/\s/g, '').replace(',', '.'));
  const decimals = numberText.split(/[,.]/)[1]?.length ?? 0;
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!Number.isFinite(target)) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setCount(target);
      return;
    }
    let frame = 0;
    const start = performance.now();
    const duration = 950;
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(target * eased);
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target]);

  const formatted = new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(count);
  return <>{prefix}{formatted}{suffix}</>;
}

function Stats({ slide }: { slide: PresentationSlide }) {
  if (!slide.stats?.length) return null;
  const chartStats = slide.stats.filter((stat) => typeof stat.chartValue === 'number');
  const maxChartValue = Math.max(...chartStats.map((stat) => stat.chartValue ?? 0), 1);
  return <>
    {chartStats.length > 1 && <div className="stat-chart" role="img" aria-label="Comparaison des arrivées touristiques observées en 2024 et 2025">
      {chartStats.map((stat) => <div className="stat-chart-row" key={stat.year}>
        <span className="stat-chart-year">{stat.year.slice(0, 4)}</span>
        <div className="stat-chart-track"><span className="stat-chart-fill" style={{ width: `${((stat.chartValue ?? 0) / maxChartValue) * 100}%` }} /></div>
        <span className="stat-chart-value">{stat.value}</span>
      </div>)}
      <span className="stat-chart-note">ARRIVÉES TOURISTIQUES · MILLIONS</span>
    </div>}
    <div className="stat-grid">{slide.stats.map((stat) => <article className="stat-card" key={`${stat.value}-${stat.label}`}>
      <div className="stat-value"><AnimatedCounter value={stat.value} /></div>
      <div className="stat-label">{stat.label}</div>
      <div className="stat-source">{stat.year} · {stat.status === 'target' ? 'OBJECTIF' : 'OBSERVÉ'}<br />{stat.source}<br /><a className="source-link" href={stat.sourceUrl} target="_blank" rel="noreferrer">Consulter la source</a></div>
    </article>)}</div>
  </>;
}

const discoveryStops = [
  {
    title: 'Kasbah d’Agadir',
    tag: 'FICHE DE LIEU',
    body: 'Un exemple de lieu visible dans la capture fournie. Sélectionnez un repère pour parcourir le principe de découverte.',
    left: '27%',
    top: '28%',
  },
  {
    title: 'Événement culturel',
    tag: 'FICHE ÉVÉNEMENT',
    body: 'La capture d’événement montre le type d’information qu’un visiteur peut consulter pour prolonger sa découverte.',
    left: '63%',
    top: '43%',
  },
  {
    title: 'Adresse locale',
    tag: 'ACTEUR LOCAL',
    body: 'Une fiche d’établissement peut ouvrir une piste locale. La capture ne confirme aucun partenariat commercial.',
    left: '43%',
    top: '68%',
  },
];

function InteractiveDiscovery() {
  const [selected, setSelected] = useState(0);
  const stop = discoveryStops[selected];
  return <div className="discovery-demo">
    <div className="discovery-map" role="group" aria-label="Carte schématique interactive de découverte">
      <svg className="discovery-map-drawing" viewBox="0 0 620 320" aria-hidden="true">
        <defs>
          <pattern id="map-grid" width="28" height="28" patternUnits="userSpaceOnUse">
            <path d="M 28 0 L 0 0 0 28" fill="none" stroke="rgba(225,235,180,.09)" strokeWidth="1" />
          </pattern>
          <linearGradient id="map-coast" x1="0" x2="1">
            <stop offset="0" stopColor="#112321" />
            <stop offset="1" stopColor="#17201a" />
          </linearGradient>
        </defs>
        <rect width="620" height="320" fill="url(#map-coast)" />
        <rect width="620" height="320" fill="url(#map-grid)" />
        <path d="M0 0H244c-32 42-14 64 7 91 22 29-17 55-4 88 12 29-11 55-5 82 5 24-17 42-27 59H0Z" fill="#0c1110" />
        <path d="M238 0c-32 42-14 64 7 91 22 29-17 55-4 88 12 29-11 55-5 82 5 24-17 42-27 59" fill="none" stroke="#dce97b" strokeOpacity=".52" strokeWidth="2" />
        <path d="M284 20c48 35 15 60 48 88s-5 55 34 79 4 56 35 78 18 28 8 41" fill="none" stroke="#c7d558" strokeOpacity=".19" strokeWidth="1" />
        <path d="M360 4c18 44 60 32 53 78s50 38 31 83 38 39 17 90 23 43 41 59" fill="none" stroke="#c7d558" strokeOpacity=".17" strokeWidth="1" />
        <path d="M226 110c105-30 207 6 357-10M214 178c93-12 193 31 389 18M211 238c115-19 209 38 381 29" fill="none" stroke="#e1ebc0" strokeOpacity=".12" strokeWidth="1" />
        <text x="58" y="294" fill="#94a199" fontSize="11" letterSpacing="3">ATLANTIQUE</text>
        <text x="394" y="294" fill="#e5f523" fontSize="11" letterSpacing="3">AGADIR · SOUSS-MASSA</text>
      </svg>
      {discoveryStops.map((item, index) => <button
        key={item.title}
        className={`discovery-pin ${selected === index ? 'active' : ''}`}
        style={{ left: item.left, top: item.top }}
        onClick={() => setSelected(index)}
        aria-pressed={selected === index}
        data-testid={`button-map-stop-${index + 1}`}
      >
        <span className="discovery-pin-dot" />
        <span>{item.title}</span>
      </button>)}
      <span className="discovery-map-caption">SCHÉMA INTERACTIF · PAS UNE CARTE EN TEMPS RÉEL</span>
    </div>
    <aside className="discovery-detail" aria-live="polite">
      <span className="slide-kicker">{stop.tag}</span>
      <h2>{stop.title}</h2>
      <p>{stop.body}</p>
      <div className="discovery-selectors">{discoveryStops.map((item, index) => <button key={item.title} onClick={() => setSelected(index)} aria-label={`Afficher ${item.title}`} aria-pressed={selected === index} data-testid={`button-discovery-select-${index + 1}`}>{String(index + 1).padStart(2, '0')}</button>)}</div>
    </aside>
  </div>;
}

function SlideBody({ slide, index, phase, phaseStartedAt, onLaunch, soundOn, toggleSound }: {
  slide: PresentationSlide; index: number; phase: RocketPhase; phaseStartedAt: number; onLaunch: () => void; soundOn: boolean; toggleSound: () => void;
}) {
  const isFinal = slide.kind === 'launch';
  const isDemo = slide.kind === 'demo';
  const seconds = phase === 'countdown' ? Math.max(1, 3 - Math.floor((Date.now() - phaseStartedAt) / 1000)) : 0;
  const countdown = phase === 'countdown';
  const launched = phase === 'ignition' || phase === 'flight' || phase === 'success';
  return (
    <main className={`slide-content ${isDemo ? 'demo-slide' : ''} ${isFinal ? 'launch-content' : ''}`}>
      <div className="slide-kicker">{slide.kicker}</div>
      {isFinal ? (
        <>
          {phase === 'success' ? <><h1 className="slide-title">{slide.title}</h1><p className="launch-status">{slide.subtitle?.toUpperCase()}</p></> :
            <><h1 className="slide-title">THE NEXT CHAPTER<br /><span className="lime">STARTS NOW.</span></h1><p className="slide-subtitle">{slide.body}</p></>}
          {countdown && <div className="launch-status" aria-live="polite">{seconds}</div>}
          {phase === 'success' ? <div className="launch-status">{slide.slogan}</div> : <button data-testid="button-launch-safarone" className="launch-button" onClick={onLaunch} disabled={countdown || launched}>{launched ? 'SAFARONE EN ROUTE' : 'LANCER SAFARONE'}</button>}
          <button className="control-button" onClick={toggleSound} aria-label={soundOn ? 'Désactiver le son' : 'Activer le son'} data-testid="button-toggle-sound">{soundOn ? <Volume2 size={15} /> : <VolumeX size={15} />} SOUND {soundOn ? 'ON' : 'OFF'}</button>
          {(phase === 'success' || launched) && <button className="control-button" onClick={onLaunch} data-testid="button-replay-launch"><RotateCcw size={14} /> REPLAY</button>}
        </>
      ) : (
        <>
          <h1 className="slide-title">{slide.title}</h1>
          {slide.subtitle && <p className="slide-subtitle">{slide.subtitle}</p>}
          {slide.quote && <blockquote className="quote">“{slide.quote}”</blockquote>}
          {slide.kind === 'cover' && <div className="slide-status lime mono" style={{ marginTop: 26 }}>{slide.slogan}</div>}
          {slide.kind === 'cover' && slide.secondarySlogan && <div className="cover-secondary">{slide.secondarySlogan}</div>}
          {slide.closingLines?.length ? <div className="slide-body lime mono closing-lines">{slide.closingLines.map((line) => <div key={line}>{line}</div>)}</div> : null}
          {slide.body && <p className="slide-body">{slide.body}</p>}
          {slide.images?.length ? <div className="image-pair">{slide.images.map((image) => <figure className="demo-figure" key={image.src}><img src={image.src} alt={image.alt} /><figcaption>{image.label}</figcaption></figure>)}</div> : null}
          <Stats slide={slide} />
          {slide.id === 10 ? <InteractiveDiscovery /> : <ItemGrid slide={slide} />}
          {slide.sourceNote && <div className="status-note">{slide.sourceNote}</div>}
        </>
      )}
      {slide.statusNote && !isFinal && <div className="status-note">{slide.statusNote}</div>}
      {slide.id === 10 && <div className="scene-map-label">AGADIR · SOUSS-MASSA / RELIEF &amp; POINTS OF DÉCOUVERTE</div>}
      {slide.id === 24 && <div className="scene-map-label">CONNAISSANCES · SOURCES · TERRITOIRES</div>}
    </main>
  );
}

export function LaunchPresentation({ state, update }: Props) {
  const [navOpen, setNavOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [timeNow, setTimeNow] = useState(Date.now());
  const slide = slides[Math.min(slides.length - 1, Math.max(0, state.index))];
  const progress = useMemo(() => ((state.index + 1) / slides.length) * 100, [state.index]);
  const change = useCallback((index: number) => update({ index: Math.max(0, Math.min(slides.length - 1, index)) }), [update]);
  const launch = useCallback(() => {
    update({ phase: 'countdown', phaseStartedAt: Date.now() });
    if (soundOn && 'AudioContext' in window) {
      try {
        const context = new AudioContext();
        const osc = context.createOscillator(), gain = context.createGain();
        osc.type = 'sine'; osc.frequency.setValueAtTime(540, context.currentTime); osc.frequency.exponentialRampToValueAtTime(190, context.currentTime + 1.1);
        gain.gain.setValueAtTime(.09, context.currentTime); gain.gain.exponentialRampToValueAtTime(.001, context.currentTime + 1.2);
        osc.connect(gain); gain.connect(context.destination); osc.start(); osc.stop(context.currentTime + 1.2); osc.onended = () => void context.close();
      } catch { /* sound is an optional enhancement */ }
    }
  }, [soundOn, update]);

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === 'PageDown' || event.key === ' ') { event.preventDefault(); change(state.index + 1); }
      else if (event.key === 'ArrowLeft' || event.key === 'PageUp') { event.preventDefault(); change(state.index - 1); }
      else if (event.key.toLowerCase() === 'f') void document.documentElement.requestFullscreen?.();
      else if (event.key.toLowerCase() === 'g') setNavOpen((open) => !open);
      else if (event.key === 'Escape') setNavOpen(false);
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [change, state.index]);
  useEffect(() => {
    if (state.phase !== 'countdown') return;
    const timer = window.setInterval(() => {
      const elapsed = Date.now() - state.phaseStartedAt;
      setTimeNow(Date.now());
      if (elapsed >= 3000) update({ phase: 'ignition', phaseStartedAt: Date.now() });
    }, 120);
    return () => window.clearInterval(timer);
  }, [state.phase, state.phaseStartedAt, update]);
  useEffect(() => {
    if (state.phase !== 'ignition') return;
    const timer = window.setTimeout(() => update({ phase: 'flight', phaseStartedAt: Date.now() }), 950);
    return () => window.clearTimeout(timer);
  }, [state.phase, update]);
  useEffect(() => {
    if (state.phase !== 'flight') return;
    const timer = window.setTimeout(() => update({ phase: 'success', phaseStartedAt: Date.now() }), 5200);
    return () => window.clearTimeout(timer);
  }, [state.phase, update]);
  useEffect(() => {
    const timer = window.setInterval(() => setTimeNow(Date.now()), 250);
    return () => window.clearInterval(timer);
  }, []);
  const toggleFullscreen = () => document.fullscreenElement ? void document.exitFullscreen() : void document.documentElement.requestFullscreen?.();
  const toggleSound = () => setSoundOn((value) => !value);
  const isCover = slide.id === 1;
  return (
    <>
      <section className={`slide-frame ${slide.kind === 'launch' ? 'launch-slide' : ''}`} data-testid={`slide-${slide.id}`}>
        {slide.kind === 'launch' ? <RocketScene phase={state.phase} phaseStartedAt={state.phaseStartedAt} /> : <ImmersiveScene slideId={slide.id} isCover={isCover} isCinematic={slide.id === 10 || slide.id === 24 || slide.id === 25 || slide.id === 30} />}
        <header className="slide-top">
          <div className="brand-lockup"><img src="/safarone-mark.png" alt="" /><span>SAFARONE</span></div>
          <div className="action-row">
            <button className="control-button" aria-label="Choisir une diapositive" onClick={() => setNavOpen(true)} data-testid="button-slide-list"><List size={16} /><span className="mono">{String(state.index + 1).padStart(2, '0')} / {slides.length}</span></button>
            <button className="control-button" aria-label="Plein écran" onClick={toggleFullscreen} data-testid="button-fullscreen"><Expand size={16} /></button>
          </div>
        </header>
        <SlideBody key={slide.id} slide={slide} index={state.index} phase={state.phase} phaseStartedAt={state.phaseStartedAt || timeNow} onLaunch={launch} soundOn={soundOn} toggleSound={toggleSound} />
        <footer className="slide-footer"><span>{slide.chapter.toUpperCase()}</span><div className="presenter-mini"><button className="control-button" onClick={() => change(state.index - 1)} aria-label="Diapositive précédente" data-testid="button-previous"><ArrowLeft size={15} /></button><button className="control-button" onClick={() => change(state.index + 1)} disabled={state.index >= slides.length - 1} aria-label="Diapositive suivante" data-testid="button-next"><ArrowRight size={15} /></button></div><span className="slide-counter">{String(state.index + 1).padStart(2, '0')}</span></footer>
        <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
      </section>
       {navOpen && <div className="slide-nav-drawer" role="dialog" aria-modal="true" aria-label="Choisir une diapositive"><div style={{ width: 'min(1050px,100%)' }}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}><div><div className="slide-kicker">SAFARONE · PRÉSENTATION</div><h2 className="display" style={{ margin: 0, fontSize: 32 }}>Aller à une diapositive</h2></div><button className="control-button" onClick={() => setNavOpen(false)} aria-label="Fermer" data-testid="button-close-slide-list"><X /></button></div><div className="slide-nav-grid">{slides.map((item, index) => <button key={item.id} className={`slide-nav-item ${index === state.index ? 'active' : ''}`} onClick={() => { change(index); setNavOpen(false); }} data-testid={`button-select-slide-${item.id}`}><span>{String(item.id).padStart(2, '0')} · {item.chapter}</span>{item.title}</button>)}</div><div className="fall-back-label" style={{ marginTop: 16 }}>KEYBOARD · ← → NAVIGUER · G DIAPOSITIVES · F PLEIN ÉCRAN</div><div className="source-list" style={{ marginTop: 14 }}>{sourceLinks.map((link) => <a className="source-link" target="_blank" rel="noreferrer" href={link.url} key={link.url}>{link.label}</a>)}</div></div></div>}
    </>
  );
}
