import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

function terrainHeight(x: number, y: number) {
  const peak = (cx: number, cy: number, sx: number, sy: number, strength: number) =>
    strength * Math.exp(-(((x - cx) / sx) ** 2 + ((y - cy) / sy) ** 2));
  const inlandRidge = .38 * Math.exp(-Math.pow((y - (1.65 + .62 * Math.sin(x * .34))) / .62, 2));
  const folds = .09 * Math.sin(x * .78 + y * .5) + .065 * Math.cos(y * 1.05 - x * .22);
  return -.12 + peak(2.7, 3.55, 3.2, 2.55, 1.42) + peak(-2.5, 5.45, 2.7, 2.2, .9) +
    peak(6.35, 6.1, 2.25, 2.8, 1.08) + inlandRidge + folds;
}

function makeRelief() {
  const columns = 112;
  const rows = 76;
  const left = -8.8;
  const width = 17.6;
  const shoreY = (x: number) => -3.05 + .58 * Math.sin(x * .34) + .2 * Math.sin(x * .79);
  const positions = new Float32Array((columns + 1) * (rows + 1) * 3);
  for (let row = 0; row <= rows; row++) {
    const t = row / rows;
    for (let col = 0; col <= columns; col++) {
      const x = left + (col / columns) * width;
      const y = shoreY(x) + t * 10.2;
      const index = (row * (columns + 1) + col) * 3;
      positions[index] = x;
      positions[index + 1] = y;
      positions[index + 2] = terrainHeight(x, y);
    }
  }
  const indices: number[] = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < columns; col++) {
      const a = row * (columns + 1) + col;
      const b = a + 1;
      const c = a + columns + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  const surface = new THREE.BufferGeometry();
  surface.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  surface.setIndex(indices);
  surface.computeVertexNormals();

  const contourPositions: number[] = [];
  const levels = [.16, .38, .6, .82, 1.04, 1.26, 1.48, 1.7, 1.92, 2.14];
  const edgePairs = [[0, 1], [1, 2], [2, 3], [3, 0]];
  for (const level of levels) {
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < columns; col++) {
        const cell = [
          row * (columns + 1) + col,
          row * (columns + 1) + col + 1,
          (row + 1) * (columns + 1) + col + 1,
          (row + 1) * (columns + 1) + col,
        ];
        const crossing: number[][] = [];
        for (const [a, b] of edgePairs) {
          const ia = cell[a] * 3, ib = cell[b] * 3;
          const ha = positions[ia + 2], hb = positions[ib + 2];
          if ((ha < level && hb >= level) || (hb < level && ha >= level)) {
            const mix = (level - ha) / (hb - ha);
            crossing.push([
              positions[ia] + (positions[ib] - positions[ia]) * mix,
              positions[ia + 1] + (positions[ib + 1] - positions[ia + 1]) * mix,
              level + .012,
            ]);
          }
        }
        if (crossing.length === 2) contourPositions.push(...crossing[0], ...crossing[1]);
        else if (crossing.length === 4) {
          contourPositions.push(...crossing[0], ...crossing[1], ...crossing[2], ...crossing[3]);
        }
      }
    }
  }
  const contours = new THREE.BufferGeometry();
  contours.setAttribute('position', new THREE.Float32BufferAttribute(contourPositions, 3));
  return { surface, contours, shoreY, left, width };
}

export function ImmersiveScene({ slideId, isCover, isCinematic }: { slideId: number; isCover: boolean; isCinematic: boolean }) {
  const host = useRef<HTMLDivElement>(null);
  const rig = useRef<THREE.Group | null>(null);
  const slideIdRef = useRef(slideId);
  const updateSlideRef = useRef<(id: number) => void>(() => {});
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, powerPreference: 'low-power' });
    } catch {
      setFailed(true);
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, 1, .1, 100);
    const root = new THREE.Group();
    const landscape = new THREE.Group();
    root.add(landscape);
    landscape.rotation.x = -.55;
    landscape.position.set(1.2, -.55, -.15);
    scene.add(root);
    rig.current = root;

    scene.add(new THREE.HemisphereLight(0x8d9b6a, 0x101313, 1.05));
    const keyLight = new THREE.DirectionalLight(0xe6efa7, 2.9);
    keyLight.position.set(-3, 7, 7);
    scene.add(keyLight);
    const limeLight = new THREE.PointLight(0xd8ed32, 18, 21, 1.6);
    limeLight.position.set(3.2, 2.4, 3.3);
    scene.add(limeLight);
    const edgeLight = new THREE.PointLight(0x91a73a, 7, 16, 1.8);
    edgeLight.position.set(-5.2, -1, 1.2);
    scene.add(edgeLight);

    const extraGeometries: THREE.BufferGeometry[] = [];
    const extraMaterials: THREE.Material[] = [];
    const geometry = (value: THREE.BufferGeometry) => {
      extraGeometries.push(value);
      return value;
    };
    const material = (value: THREE.Material) => {
      extraMaterials.push(value);
      return value;
    };
    const glow = (color: number, emissive: number, opacity = 1) => material(new THREE.MeshStandardMaterial({
      color,
      emissive,
      emissiveIntensity: .7,
      metalness: .32,
      roughness: .36,
      transparent: opacity < 1,
      opacity,
      depthWrite: opacity === 1,
    }));
    const line = (color: number, opacity: number) => material(new THREE.LineBasicMaterial({
      color,
      transparent: true,
      opacity,
      depthWrite: false,
    }));

    const productScene = new THREE.Group();
    productScene.position.set(3.8, .2, .6);
    productScene.scale.setScalar(.92);
    scene.add(productScene);
    const mapHalo = new THREE.Mesh(
      geometry(new THREE.TorusGeometry(1.68, .018, 6, 96)),
      glow(0xe1ef4a, 0x74820f, .88),
    );
    mapHalo.rotation.set(.22, -.28, -.2);
    productScene.add(mapHalo);
    const mapRing = new THREE.Mesh(
      geometry(new THREE.TorusGeometry(1.04, .012, 5, 80)),
      glow(0xe0e9c2, 0x626b35, .64),
    );
    mapRing.rotation.set(-.18, .48, .26);
    productScene.add(mapRing);
    const locationPin = new THREE.Group();
    const pinStem = new THREE.Mesh(
      geometry(new THREE.CylinderGeometry(.075, .12, .38, 14)),
      glow(0xe7ef75, 0x677514),
    );
    pinStem.position.y = -.12;
    const pinHead = new THREE.Mesh(
      geometry(new THREE.SphereGeometry(.21, 18, 14)),
      glow(0xe6f32c, 0x95a51a),
    );
    pinHead.position.y = .12;
    locationPin.add(pinStem, pinHead);
    productScene.add(locationPin);
    const mapPoints = [
      new THREE.Vector3(-1.1, .63, .05),
      new THREE.Vector3(-.65, -.65, .08),
      new THREE.Vector3(.84, .88, -.02),
      new THREE.Vector3(1.22, -.48, .03),
      new THREE.Vector3(-1.48, -.14, .02),
    ];
    const mapPathGeometry = geometry(new THREE.BufferGeometry().setFromPoints([
      mapPoints[4], mapPoints[0], mapPoints[2], mapPoints[3], mapPoints[1],
    ]));
    productScene.add(new THREE.Line(mapPathGeometry, line(0xe1ed6b, .65)));
    const dotGeometry = geometry(new THREE.SphereGeometry(.065, 10, 8));
    const dotMaterial = glow(0xdde5b0, 0x31380f);
    const mapDots = new THREE.InstancedMesh(dotGeometry, dotMaterial, mapPoints.length);
    const dotMatrix = new THREE.Matrix4();
    mapPoints.forEach((point, index) => {
      dotMatrix.makeTranslation(point.x, point.y, point.z);
      mapDots.setMatrixAt(index, dotMatrix);
    });
    mapDots.instanceMatrix.needsUpdate = true;
    productScene.add(mapDots);

    const researchScene = new THREE.Group();
    researchScene.position.set(3.8, .2, .2);
    scene.add(researchScene);
    const knowledgeNodes = [
      new THREE.Vector3(-1.58, .34, -.13),
      new THREE.Vector3(-1.03, 1.22, .08),
      new THREE.Vector3(-.06, .82, -.16),
      new THREE.Vector3(.83, 1.28, .12),
      new THREE.Vector3(1.5, .3, -.08),
      new THREE.Vector3(.92, -.72, .16),
      new THREE.Vector3(-.02, -1.05, -.04),
      new THREE.Vector3(-1.13, -.73, .13),
      new THREE.Vector3(.03, .03, .32),
    ];
    const links = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 0], [1, 8], [3, 8], [5, 8], [7, 8], [0, 2], [4, 6]];
    const linkPositions: number[] = [];
    links.forEach(([from, to]) => {
      linkPositions.push(...knowledgeNodes[from].toArray(), ...knowledgeNodes[to].toArray());
    });
    const knowledgeGeometry = geometry(new THREE.BufferGeometry());
    knowledgeGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linkPositions, 3));
    researchScene.add(new THREE.LineSegments(knowledgeGeometry, line(0xe1ed6b, .34)));
    const nodeGeometry = geometry(new THREE.SphereGeometry(.07, 12, 10));
    const nodeMaterial = glow(0xdde5b0, 0x31380f);
    const nodeMeshes = new THREE.InstancedMesh(nodeGeometry, nodeMaterial, knowledgeNodes.length);
    knowledgeNodes.forEach((point, index) => {
      dotMatrix.makeTranslation(point.x, point.y, point.z);
      nodeMeshes.setMatrixAt(index, dotMatrix);
    });
    nodeMeshes.instanceMatrix.needsUpdate = true;
    researchScene.add(nodeMeshes);
    const knowledgeCore = new THREE.Mesh(
      geometry(new THREE.IcosahedronGeometry(.36, 1)),
      glow(0xb9c951, 0x879b20, .6),
    );
    researchScene.add(knowledgeCore);
    const knowledgeOrbit = new THREE.Mesh(
      geometry(new THREE.TorusGeometry(1.75, .01, 5, 100)),
      glow(0xe0e9c2, 0x626b35, .4),
    );
    knowledgeOrbit.rotation.set(.3, -.4, -.13);
    researchScene.add(knowledgeOrbit);

    const brandScene = new THREE.Group();
    brandScene.position.set(4.2, .2, 1.1);
    scene.add(brandScene);
    const brandCore = new THREE.Mesh(
      geometry(new THREE.IcosahedronGeometry(.7, 2)),
      glow(0xcedb45, 0x8a9c10),
    );
    brandScene.add(brandCore);
    const brandOrbitOuter = new THREE.Mesh(
      geometry(new THREE.TorusGeometry(1.55, .023, 7, 112)),
      glow(0xe7f477, 0x879618, .86),
    );
    brandOrbitOuter.rotation.set(.55, .2, -.35);
    brandScene.add(brandOrbitOuter);
    const brandOrbitInner = new THREE.Mesh(
      geometry(new THREE.TorusGeometry(1.14, .012, 5, 96)),
      glow(0xe5eacb, 0x666d39, .58),
    );
    brandOrbitInner.rotation.set(-.3, .48, .55);
    brandScene.add(brandOrbitInner);

    const relief = makeRelief();
    const land = new THREE.Mesh(relief.surface, new THREE.MeshStandardMaterial({
      color: 0x374328,
      roughness: .86,
      metalness: .08,
      emissive: 0x18220a,
      emissiveIntensity: .42,
      side: THREE.DoubleSide,
    }));
    landscape.add(land);
    const contourLines = new THREE.LineSegments(relief.contours, new THREE.LineBasicMaterial({
      color: 0xd9eb55,
      transparent: true,
      opacity: .43,
      depthWrite: false,
    }));
    landscape.add(contourLines);

    const shorelinePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 180; i++) {
      const x = relief.left + (i / 180) * relief.width;
      shorelinePoints.push(new THREE.Vector3(x, relief.shoreY(x), terrainHeight(x, relief.shoreY(x)) + .035));
    }
    const shoreline = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(shorelinePoints),
      new THREE.LineBasicMaterial({ color: 0xe8f563, transparent: true, opacity: .8 }),
    );
    landscape.add(shoreline);

    const seaGeometry = new THREE.PlaneGeometry(19, 7.3, 38, 14);
    const sea = new THREE.Mesh(seaGeometry, new THREE.MeshStandardMaterial({
      color: 0x101c1b,
      roughness: .52,
      metalness: .28,
      emissive: 0x07120e,
      emissiveIntensity: .7,
      side: THREE.DoubleSide,
    }));
    sea.position.set(0, -6.5, -.34);
    landscape.add(sea);
    const seaGrid = new THREE.LineSegments(
      new THREE.WireframeGeometry(seaGeometry),
      new THREE.LineBasicMaterial({ color: 0xa5b75a, transparent: true, opacity: .075, depthWrite: false }),
    );
    seaGrid.position.copy(sea.position);
    landscape.add(seaGrid);

    let seed = 8301;
    const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    const particleCount = Math.min(230, Math.max(105, Math.round(window.innerWidth * window.innerHeight / 7800)));
    const particlesGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = -8 + random() * 17;
      particlePositions[i * 3 + 1] = -1.4 + random() * 6.5;
      particlePositions[i * 3 + 2] = .1 + random() * 2.3;
    }
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particles = new THREE.Points(particlesGeometry, new THREE.PointsMaterial({
      color: 0xe6f565,
      size: .032,
      transparent: true,
      opacity: .62,
      sizeAttenuation: true,
      depthWrite: false,
    }));
    root.add(particles);

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.setClearColor(0x000000, 0);
    el.appendChild(renderer.domElement);
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const cameraPositionGoal = new THREE.Vector3();
    const cameraLookGoal = new THREE.Vector3();
    const animatedLook = new THREE.Vector3();
    const cameraMotion = new THREE.Vector3();
    let activeSlideId = -1;
    const setSceneForSlide = (slideId: number, snap = false) => {
      const mobile = el.clientWidth < 760;
      // Scene visibility is keyed by stable slide IDs, never array positions.
      productScene.visible = slideId === 10;
      researchScene.visible = slideId === 24 || slideId === 25;
      brandScene.visible = slideId === 1 || slideId === 30;

      if (productScene.visible) {
        cameraPositionGoal.set(mobile ? 1.6 : 1.15, mobile ? 3.25 : 2.75, mobile ? 16.2 : 12.6);
        cameraLookGoal.set(mobile ? 2.7 : 3.15, .1, 0);
      } else if (researchScene.visible) {
        cameraPositionGoal.set(mobile ? 1.6 : .8, mobile ? 3.2 : 2.55, mobile ? 16.5 : 12.7);
        cameraLookGoal.set(3.15, .05, 0);
      } else if (brandScene.visible) {
        cameraPositionGoal.set(mobile ? 1.7 : .65, mobile ? 3.35 : 2.65, mobile ? 16.8 : 13.1);
        cameraLookGoal.set(3.2, -.12, .2);
      } else {
        cameraPositionGoal.set(0, mobile ? 3.5 : 2.9, mobile ? 15.8 : 12.8);
        cameraLookGoal.set(.5, -.45, 0);
      }

      if (snap) {
        camera.position.copy(cameraPositionGoal);
        animatedLook.copy(cameraLookGoal);
        camera.lookAt(animatedLook);
      }
      activeSlideId = slideId;
    };
    updateSlideRef.current = (id: number) => {
      slideIdRef.current = id;
      setSceneForSlide(id, true);
      renderer.render(scene, camera);
    };
    let frame = 0;
    let visible = !document.hidden;
    let t = 0;
    const resize = () => {
      const w = el.clientWidth;
      const h = el.clientHeight;
      if (!w || !h) return;
      camera.aspect = w / h;
      setSceneForSlide(slideIdRef.current, true);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
      if (!visible || reduced) renderer.render(scene, camera);
    };
    const animate = () => {
      if (!visible || reduced) return;
      frame = requestAnimationFrame(animate);
      t += .003;
      if (slideIdRef.current !== activeSlideId) setSceneForSlide(slideIdRef.current);
      root.rotation.y = Math.sin(t * .32) * .035;
      landscape.rotation.z = Math.sin(t * .24) * .012;
      cameraMotion.copy(cameraPositionGoal);
      cameraMotion.x += Math.sin(t * .22) * .2;
      cameraMotion.y += Math.sin(t * .19) * .08;
      camera.position.lerp(cameraMotion, .018);
      animatedLook.lerp(cameraLookGoal, .025);
      camera.lookAt(animatedLook);
      limeLight.position.x = 3.2 + Math.sin(t * .23) * .35;
      particles.rotation.y = -t * .018;
      mapHalo.rotation.z = -.2 + Math.sin(t * .2) * .045;
      productScene.rotation.y = Math.sin(t * .18) * .06;
      researchScene.rotation.z = Math.sin(t * .14) * .025;
      knowledgeCore.rotation.y = t * .18;
      brandScene.rotation.y = t * .1;
      brandCore.rotation.x = Math.sin(t * .3) * .08;
      renderer.render(scene, camera);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(el);
    const visibility = () => {
      visible = !document.hidden;
      if (visible && !reduced) animate();
      else cancelAnimationFrame(frame);
    };
    document.addEventListener('visibilitychange', visibility);
    resize();
    if (reduced) renderer.render(scene, camera);
    else animate();
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      document.removeEventListener('visibilitychange', visibility);
      relief.surface.dispose();
      relief.contours.dispose();
      land.material.dispose();
      contourLines.material.dispose();
      shoreline.geometry.dispose();
      shoreline.material.dispose();
      seaGeometry.dispose();
      sea.material.dispose();
      seaGrid.geometry.dispose();
      seaGrid.material.dispose();
      particlesGeometry.dispose();
      particles.material.dispose();
      extraGeometries.forEach((item) => item.dispose());
      extraMaterials.forEach((item) => item.dispose());
      renderer.dispose();
      renderer.domElement.remove();
      rig.current = null;
    };
  }, []);
  useEffect(() => {
    updateSlideRef.current(slideId);
    if (rig.current) rig.current.rotation.y += (slideId % 2 ? .08 : -.08);
  }, [slideId]);
  return <div className={`scene-canvas ${isCover ? 'cinematic-cover' : ''} ${isCinematic ? 'scene-cinematic' : 'scene-quiet'} ${failed ? 'scene-fallback' : ''}`} ref={host} aria-hidden="true" />;
}
