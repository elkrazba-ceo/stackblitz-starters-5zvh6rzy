import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import type { RocketPhase } from '@/lib/launch-sync';

export function RocketScene({ phase, phaseStartedAt }: { phase: RocketPhase; phaseStartedAt: number }) {
  const host = useRef<HTMLDivElement>(null);
  const phaseRef = useRef(phase);
  const startedRef = useRef(phaseStartedAt);
  const flightStartedAt = useRef(0);
  const [failed, setFailed] = useState(false);
  const renderStaticRef = useRef<() => void>(() => {});
  useEffect(() => {
    phaseRef.current = phase;
    startedRef.current = phaseStartedAt;
    if (phase === 'flight') flightStartedAt.current = phaseStartedAt;
    renderStaticRef.current();
  }, [phase, phaseStartedAt]);

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' }); }
    catch { setFailed(true); return; }
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, .1, 100);
    camera.position.set(0, 1.2, 11);
    const ambient = new THREE.HemisphereLight(0xe6ecbd, 0x14130b, 1.5);
    scene.add(ambient);
    const key = new THREE.DirectionalLight(0xf6ff9c, 3.2);
    key.position.set(-3, 5, 6); scene.add(key);
    const rocket = new THREE.Group(); rocket.position.set(0, -1.15, 0); scene.add(rocket);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xe5e8d8, metalness: .72, roughness: .24 });
    const limeMat = new THREE.MeshStandardMaterial({ color: 0xe5f523, emissive: 0x87910b, emissiveIntensity: .32, metalness: .35, roughness: .3 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x191a15, metalness: .7, roughness: .3 });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(.32, .4, 2.35, 28, 1), bodyMat); rocket.add(body);
    const nose = new THREE.Mesh(new THREE.ConeGeometry(.32, .82, 28), limeMat); nose.position.y = 1.57; rocket.add(nose);
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(.42, .42, .13, 28), limeMat); collar.position.y = .76; rocket.add(collar);
    const windowMat = new THREE.MeshStandardMaterial({ color: 0x8fa1a0, emissive: 0x1b3c36, metalness: .85, roughness: .12 });
    const windowMesh = new THREE.Mesh(new THREE.SphereGeometry(.15, 20, 14), windowMat); windowMesh.scale.z = .42; windowMesh.position.set(0, .35, .31); rocket.add(windowMesh);
    for (const side of [-1, 1]) {
      const fin = new THREE.Mesh(new THREE.ConeGeometry(.35, .78, 4), limeMat);
      fin.scale.set(.65, 1, .25); fin.position.set(side * .35, -.82, 0); fin.rotation.z = side * -.58; rocket.add(fin);
    }
    const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(.2, .3, .42, 18), darkMat); nozzle.position.y = -1.35; rocket.add(nozzle);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(.25, 1.3, 18), new THREE.MeshBasicMaterial({ color: 0xe5f523, transparent: true, opacity: .92 }));
    flame.position.y = -2.12; flame.rotation.x = Math.PI; rocket.add(flame);
    const core = new THREE.Mesh(new THREE.ConeGeometry(.11, .87, 14), new THREE.MeshBasicMaterial({ color: 0xffe8a1, transparent: true, opacity: .96 }));
    core.position.y = -2.16; core.rotation.x = Math.PI; rocket.add(core);
    const engineLight = new THREE.PointLight(0xe5f523, 0, 12, 1.7); engineLight.position.set(0, -2, 1); scene.add(engineLight);
    const starGeo = new THREE.BufferGeometry();
    const count = 220; const positions = new Float32Array(count * 3);
    let seed = 417;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    for (let i = 0; i < count; i++) { positions[i*3] = (rnd() - .5) * 15; positions[i*3+1] = (rnd() - .5) * 10; positions[i*3+2] = -2 - rnd() * 12; }
    starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xc4cd8c, size: .025, transparent: true, opacity: .72 }));
    scene.add(stars);
    const smokeCount = 170;
    const smokePos = new Float32Array(smokeCount * 3);
    const velocities: number[] = [];
    for (let i = 0; i < smokeCount; i++) { smokePos[i*3] = (rnd()-.5)*.45; smokePos[i*3+1] = -2.3-rnd()*3; smokePos[i*3+2] = (rnd()-.5)*.4; velocities.push(.12+rnd()*.32); }
    const smokeGeo = new THREE.BufferGeometry(); smokeGeo.setAttribute('position', new THREE.BufferAttribute(smokePos, 3));
    const smoke = new THREE.Points(smokeGeo, new THREE.PointsMaterial({ color: 0xc8c7a7, size: .09, transparent: true, opacity: .28, depthWrite: false }));
    scene.add(smoke);
    let frame = 0; let running = !document.hidden; const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const resize = () => { const w = el.clientWidth, h = el.clientHeight; if (!w || !h) return; camera.aspect = w / h; camera.updateProjectionMatrix(); renderer.setSize(w, h, false); if (reduced) renderStaticRef.current(); };
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.5)); el.appendChild(renderer.domElement); resize();
    const observer = new ResizeObserver(resize); observer.observe(el);
    const renderStatic = () => {
      const now = Date.now();
      const active = phaseRef.current === 'ignition' || phaseRef.current === 'flight' || phaseRef.current === 'success';
      const flight = phaseRef.current === 'flight' || phaseRef.current === 'success';
      flame.visible = active;
      core.visible = active;
      engineLight.intensity = active ? 26 : 0;
      rocket.position.y = flight ? 8.35 : -1.15;
      rocket.rotation.z = flight ? .12 : 0;
      camera.position.y = flight ? 8.99 : 1.2;
      camera.lookAt(0, flight ? 9.19 : .2, 0);
      flame.scale.y = 1;
      renderer.render(scene, camera);
    };
    renderStaticRef.current = renderStatic;
    const animate = () => {
      if (!running || reduced) return;
      frame = requestAnimationFrame(animate);
      const now = Date.now();
      const elapsed = phaseRef.current === 'idle' ? 0 : Math.max(0, (now - startedRef.current) / 1000);
      const active = phaseRef.current === 'ignition' || phaseRef.current === 'flight' || phaseRef.current === 'success';
      flame.visible = active; core.visible = active;
      engineLight.intensity = active ? 26 + Math.sin(now * .035) * 7 : 0;
      const flight = phaseRef.current === 'flight' || phaseRef.current === 'success';
      const flightElapsed = flightStartedAt.current ? Math.max(0, (now - flightStartedAt.current) / 1000) : 0;
      const rise = flight ? Math.min(9.5, Math.max(0, flightElapsed - .1) * 2.2) : 0;
      rocket.position.y = -1.15 + rise;
      rocket.rotation.z = flight ? Math.min(.12, Math.max(0, elapsed - 1) * .012) : Math.sin(now * .0004) * .012;
      camera.position.y = flight ? 1.2 + Math.min(8.2, rise * .82) : 1.2;
      camera.lookAt(0, flight ? camera.position.y + .2 : .2, 0);
      flame.scale.y = .75 + Math.abs(Math.sin(now * .025)) * .55;
      for (let i=0;i<smokeCount;i++) {
        const y = smokePos[i*3+1] + velocities[i] * (active ? 1.25 : .12);
        smokePos[i*3+1] = y > 2 ? -2.2 - rnd()*2 : y;
        smokePos[i*3] += Math.sin(now*.001 + i) * .0018;
      }
      smokeGeo.attributes.position.needsUpdate = true;
      stars.rotation.y = now * .000025;
      renderer.render(scene, camera);
    };
    const visibility = () => { running = !document.hidden; if (running && !reduced) animate(); else cancelAnimationFrame(frame); };
    document.addEventListener('visibilitychange', visibility);
    if (reduced) renderStatic(); else animate();
    return () => {
      cancelAnimationFrame(frame); observer.disconnect(); document.removeEventListener('visibilitychange', visibility);
      scene.traverse((object) => { if (object instanceof THREE.Mesh || object instanceof THREE.Points) { object.geometry.dispose(); const m = object.material; if (Array.isArray(m)) m.forEach((mat) => mat.dispose()); else m.dispose(); } });
      renderer.dispose(); renderer.domElement.remove();
    };
  }, []);
  return <div ref={host} className={`rocket-host ${failed ? 'scene-fallback' : ''}`} aria-hidden="true" />;
}
