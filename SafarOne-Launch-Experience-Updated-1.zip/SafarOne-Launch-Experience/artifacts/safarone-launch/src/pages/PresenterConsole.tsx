import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Copy, ExternalLink, MonitorPlay, PencilLine } from 'lucide-react';
import { slides, type PresentationSlide } from '@/data/slides';
import type { LaunchState } from '@/lib/launch-sync';

type ScriptEntry = { slideId: number; script: string; talkingPoints: string[]; notesPrompt: string };
type Props = { state: LaunchState; update: (patch: Partial<LaunchState>) => void };

function formatTime(totalSeconds: number) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((v) => String(v).padStart(2, '0')).join(':');
}

function RehearsalSlide({ slide }: { slide: PresentationSlide }) {
  return <div className="presenter-preview" data-testid="rehearsal-slide">
    <div className="slide-kicker">{slide.kicker}</div>
    <h2 className="slide-title">{slide.title}</h2>
    {slide.subtitle && <p className="slide-subtitle">{slide.subtitle}</p>}
    {slide.quote && <blockquote className="quote">{slide.quote}</blockquote>}
    {slide.body && <p className="slide-body">{slide.body}</p>}
    {slide.images && <div className="image-pair">{slide.images.map((image) => <figure className="demo-figure" key={image.src}><img src={image.src} alt={image.alt} /><figcaption>{image.label}</figcaption></figure>)}</div>}
    {slide.items && <div className="items-grid">{slide.items.map((item) => <article key={item.title} className="item-card"><h3>{item.title}</h3><p>{item.body}</p></article>)}</div>}
    {slide.stats && <div className="stat-grid">{slide.stats.map((stat) => <div className="stat-card" key={stat.value}><div className="stat-value">{stat.value}</div><div className="stat-label">{stat.label}</div><div className="stat-source">{stat.year} · {stat.status === 'target' ? 'OBJECTIF' : 'OBSERVÉ'} · {stat.source}</div></div>)}</div>}
    {slide.closingLines?.length ? <p className="slide-body lime mono">{slide.closingLines.map((line) => <span key={line}>{line}<br /></span>)}</p> : null}
    {slide.statusNote && <div className="status-note">{slide.statusNote}</div>}
  </div>;
}

export default function PresenterConsole({ state, update }: Props) {
  const [scripts, setScripts] = useState<ScriptEntry[]>([]);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [elapsed, setElapsed] = useState(0);
  const [fallback, setFallback] = useState(false);
  const [rehearsal, setRehearsal] = useState(false);
  const current = slides[Math.max(0, Math.min(slides.length - 1, state.index))];
  const next = slides[state.index + 1];
  const script = scripts.find((item) => item.slideId === current.id);
  const publicUrl = useMemo(() => `${window.location.origin}${import.meta.env.BASE_URL}?mode=public`, []);

  useEffect(() => {
    let alive = true;
    import('@/data/speakerScripts').then(({ speakerScripts }) => { if (alive) setScripts(speakerScripts); });
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    try {
      const saved = localStorage.getItem('safarone-presenter-notes-v1');
      if (saved) setNotes(JSON.parse(saved) as Record<number, string>);
    } catch { /* notes remain editable if local storage is unavailable */ }
  }, []);
  useEffect(() => {
    const started = Date.now();
    const tick = () => setElapsed(Math.floor((Date.now() - started) / 1000));
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLInputElement) return;
      if (event.key === 'ArrowRight' || event.key === 'PageDown') {
        event.preventDefault();
        update({ index: Math.min(slides.length - 1, state.index + 1) });
      } else if (event.key === 'ArrowLeft' || event.key === 'PageUp') {
        event.preventDefault();
        update({ index: Math.max(0, state.index - 1) });
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [state.index, update]);
  const move = (delta: number) => update({ index: Math.max(0, Math.min(slides.length - 1, state.index + delta)) });
  const launchRocket = () => update({ phase: 'countdown', phaseStartedAt: Date.now() });
  const openAudience = () => {
    const popup = window.open(publicUrl, 'safarone-audience', 'popup,width=1440,height=900');
    if (!popup) setFallback(true);
    else { popup.focus(); setFallback(false); }
  };
  const copyLink = async () => {
    try { await navigator.clipboard.writeText(publicUrl); setFallback(true); }
    catch { setFallback(true); }
  };
  const saveNote = (value: string) => {
    const updated = { ...notes, [current.id]: value };
    setNotes(updated);
    try { localStorage.setItem('safarone-presenter-notes-v1', JSON.stringify(updated)); } catch { /* visible in this session */ }
  };

  return <div className="presenter-shell" data-testid="presenter-console">
    <main className="presenter-main">
      <div className="presenter-header">
        <div className="brand-lockup"><img src="/safarone-mark.png" alt="" /><span>SAFARONE / PRESENTATION DESK</span></div>
        <span className="mono">PRIVATE · PRESENTER VIEW</span>
      </div>
      <div className="presenter-preview">
        <div className="slide-kicker">{current.chapter} · {current.kicker}</div>
        <h1 className="slide-title">{current.title}</h1>
        {current.subtitle && <p className="slide-subtitle">{current.subtitle}</p>}
        {current.quote && <blockquote className="quote">{current.quote}</blockquote>}
        {current.body && <p className="slide-body">{current.body}</p>}
        {current.images && <div className="image-pair">{current.images.map((image) => <figure className="demo-figure" key={image.src}><img src={image.src} alt={image.alt} /><figcaption>{image.label}</figcaption></figure>)}</div>}
        {current.id === 32 && <p className="slide-body lime mono">FROM A LOCAL INITIATIVE IN AGADIR TO A NATIONAL TOURISM TECHNOLOGY VISION.<br />OUR AMBITION: ALL OF MOROCCO BY 2030.</p>}
        <div className="presenter-header" style={{ marginTop: 22 }}><span className="mono">{String(state.index + 1).padStart(2, '0')} / {slides.length} · {current.chapter.toUpperCase()}</span><span className="timer">{formatTime(elapsed)}</span></div>
      </div>
      <div className="presenter-controls">
        <button className="control-button" onClick={() => move(-1)} disabled={state.index === 0} data-testid="button-presenter-previous"><ArrowLeft size={15} /> PRÉCÉDENTE</button>
        <button className="control-button primary" onClick={() => move(1)} disabled={state.index >= slides.length - 1} data-testid="button-presenter-next">SUIVANTE <ArrowRight size={15} /></button>
        <button className="control-button" onClick={() => setRehearsal((value) => !value)} data-testid="button-rehearsal"><PencilLine size={15} /> {rehearsal ? 'FERMER RÉPÉTITION' : 'RÉPÉTITION'}</button>
        {current.kind === 'launch' && <button className="control-button primary" onClick={launchRocket} disabled={state.phase === 'countdown' || state.phase === 'ignition' || state.phase === 'flight'} data-testid="button-presenter-launch-safarone">{state.phase === 'success' ? 'REJOUER LA SÉQUENCE' : 'LANCER SAFARONE'}</button>}
        <div style={{ flex: 1 }} />
        <button className="control-button primary" onClick={openAudience} data-testid="button-open-audience"><MonitorPlay size={15} /> OUVRIR LE PUBLIC</button>
      </div>
      {fallback && <div className="presenter-card" role="status"><strong className="lime">Fenêtre publique non ouverte ?</strong><p>Ouvrez ce lien dans une autre fenêtre ou copiez-le pour un second écran.</p><a className="share-link" href={publicUrl} target="_blank" rel="noreferrer" data-testid="link-public-window">{publicUrl}</a><button className="control-button" style={{ marginTop: 12 }} onClick={copyLink} data-testid="button-copy-public-link"><Copy size={14} /> COPIER LE LIEN</button></div>}
      {rehearsal && <div className="rehearsal-banner" data-testid="rehearsal-warning">RÉPÉTITION SUR UN SEUL ÉCRAN — ce mode affiche le contenu de présentation dans cette console. Ce n’est pas une configuration sûre pour un projecteur. Pour la présentation réelle, ouvrez une fenêtre publique séparée.</div>}
    </main>
    <aside className="presenter-aside">
      <div>
        <div className="slide-kicker">PRISE DE PAROLE · FRANÇAIS</div>
        <h2 className="presenter-title">Script de la diapositive</h2>
        <div className="presenter-card"><p data-testid="text-current-script">{script?.script ?? 'Chargement du script de présentation…'}</p></div>
      </div>
      <div>
        <div className="slide-kicker">À GARDER EN TÊTE</div>
        <ul className="talking-list" data-testid="list-talking-points">{(script?.talkingPoints ?? []).map((point, index) => <li key={`${index}-${point}`}>{point}</li>)}</ul>
        {!script && <div className="presenter-card"><p>Les éléments de prise de parole se chargent dans la console privée.</p></div>}
      </div>
      <div className="presenter-card">
        <div className="slide-kicker">{next ? `PROCHAINE · ${String(next.id).padStart(2, '0')}` : 'FIN DE LA PRÉSENTATION'}</div>
        <div className="next-preview" data-testid="text-next-slide">{next?.title ?? 'Séquence de lancement terminée'}</div>
      </div>
      <div>
        <div className="slide-kicker">NOTES PERSONNELLES · SAUVEGARDÉES SUR CET APPAREIL</div>
        <textarea className="presenter-notes" value={notes[current.id] ?? ''} onChange={(event) => saveNote(event.target.value)} placeholder={script?.notesPrompt ?? 'Notes privées pour cette diapositive…'} aria-label="Notes personnelles" data-testid="input-presenter-notes" />
      </div>
      <div className="presenter-card">
        <div className="slide-kicker">PRÉSENTATION EN COURS</div>
        <p><span className="lime">{String(state.index + 1).padStart(2, '0')} / {slides.length}</span> · {current.chapter}</p>
        <p style={{ marginTop: 8 }}>Temps écoulé <span className="timer">{formatTime(elapsed)}</span></p>
        <button className="control-button" style={{ marginTop: 14 }} onClick={openAudience} data-testid="button-presenter-open-window"><ExternalLink size={14} /> OUVRIR LA FENÊTRE PUBLIC</button>
      </div>
      <div className="fall-back-label">SCRIPTS ET NOTES RESTENT DANS CETTE CONSOLE. ILS NE SONT PAS TRANSMIS À LA FENÊTRE PUBLIC.</div>
    </aside>
    {rehearsal && <div className="slide-nav-drawer" role="dialog" aria-modal="true" aria-label="Mode répétition"><div style={{ width: 'min(1320px,100%)', maxHeight: '92dvh', overflow: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}><div><span className="slide-kicker">RÉPÉTITION · NON PROJECTEUR-SAFE</span><p className="fall-back-label">SLIDE ET SCRIPT PARTAGENT UN SEUL ÉCRAN.</p></div><button className="control-button" onClick={() => setRehearsal(false)} data-testid="button-close-rehearsal">FERMER</button></div>
      <div className="rehearsal-layout"><RehearsalSlide slide={current} /><div className="presenter-card"><div className="slide-kicker">SCRIPT · FRANÇAIS</div><p>{script?.script ?? 'Chargement du script de présentation…'}</p><div className="slide-kicker" style={{ marginTop: 22 }}>POINTS CLÉS</div><ul className="talking-list">{(script?.talkingPoints ?? []).map((point) => <li key={point}>{point}</li>)}</ul><div className="slide-kicker" style={{ marginTop: 22 }}>NOTES PERSONNELLES</div><textarea className="presenter-notes" value={notes[current.id] ?? ''} onChange={(event) => saveNote(event.target.value)} placeholder={script?.notesPrompt ?? 'Notes privées…'} aria-label="Notes personnelles de répétition" /></div></div>
      <div className="presenter-controls"><button className="control-button" onClick={() => move(-1)}><ArrowLeft size={15} /> PRÉCÉDENTE</button><button className="control-button primary" onClick={() => move(1)}>SUIVANTE <ArrowRight size={15} /></button></div>
    </div></div>}
  </div>;
}
