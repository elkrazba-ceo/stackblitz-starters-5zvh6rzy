export type SpeakerScript = {
  slideId: number;
  script: string;
  talkingPoints: string[];
  notesPrompt: string;
};

export const speakerScripts: SpeakerScript[] = [
  {
    slideId: 1,
    script: 'Bonsoir à toutes et à tous, et bienvenue à Agadir. Aujourd’hui, le 15 décembre 2026, nous lançons officiellement SafarOne, un projet né d’une conviction simple : voyager, c’est aussi comprendre. Nous sommes heureux de vous accueillir à la Cité de l’Innovation Souss-Massa pour partager cette vision, vous montrer le produit et ouvrir la conversation avec celles et ceux qui font vivre le tourisme marocain.',
    talkingPoints: ['Lancement officiel à Agadir, le 15 décembre 2026', 'SafarOne est porté par HK Solutions SARL', 'Annonce du fil conducteur : découvrir les lieux à travers leurs histoires'],
    notesPrompt: 'Remercier les invités et les équipes présentes.',
  },
  {
    slideId: 2,
    script: 'Notre signature résume l’intention de SafarOne : “Beyond places. Into stories.” Un lieu est davantage qu’un point sur une carte. Il porte une mémoire, une culture, des gestes et des rencontres. Nous voulons aider le visiteur à passer du lieu qu’il regarde à l’histoire qu’il peut comprendre, tout en respectant la richesse de ce qui existe déjà sur le territoire.',
    talkingPoints: ['Présenter le slogan officiel', 'Expliquer le passage du repère géographique au récit', 'Insister sur la découverte comme expérience, pas seulement navigation'],
    notesPrompt: 'Ajouter un exemple personnel de lieu qui mérite d’être raconté.',
  },
  {
    slideId: 3,
    script: 'SafarOne est né à partir d’une question très concrète : une personne arrive dans une ville, repère un lieu, mais comment accède-t-elle facilement à son histoire et à ce qu’elle peut vivre autour ? Notre point de départ est Agadir et Souss-Massa. Nous ne prétendons pas que tout est déjà construit. Nous présentons aujourd’hui une première expérience et une ambition que nous souhaitons valider avec les acteurs du territoire.',
    talkingPoints: ['Le projet part d’un problème de découverte', 'Agadir et Souss-Massa sont le point de départ', 'La validation terrain reste une étape à construire'],
    notesPrompt: 'Raconter brièvement ce qui a motivé la première version.',
  },
  {
    slideId: 4,
    script: 'Derrière SafarOne, il y a deux fondateurs. Je suis Khalid EL KRAZBA, Co-Founder & CEO, et Hayat IDBIHI est Co-Founder & CTO. Nous avons des responsabilités différentes, mais une ambition commune : construire un produit utile, ancré dans la réalité touristique marocaine et capable d’évoluer au contact des visiteurs et des professionnels.',
    talkingPoints: ['Khalid EL KRAZBA — Co-Founder & CEO', 'Hayat IDBIHI — Co-Founder & CTO', 'Présenter les responsabilités sans ajouter de biographie non vérifiée'],
    notesPrompt: 'Prévoir qui prend la parole et dans quel ordre.',
  },
  {
    slideId: 5,
    script: 'Nous voulons aussi remercier Monsieur Rachid El Maayfi. Il a pris en charge les frais de création de HK Solutions SARL, qui porte SafarOne. Ce soutien a compté au commencement du projet. Nous tenions à le nommer publiquement et à lui exprimer notre reconnaissance, au nom des fondateurs.',
    talkingPoints: ['Remercier Rachid El Maayfi', 'Mentionner uniquement le soutien communiqué dans le support initial', 'Ne pas ajouter de montant ou d’autre contribution'],
    notesPrompt: 'Ajouter un remerciement personnel si souhaité.',
  },
  {
    slideId: 6,
    script: 'Quand on visite un lieu, on peut en voir la beauté sans en saisir tout le sens. Les informations sont souvent dispersées entre des cartes, des pages web et des supports différents. Le défi n’est pas de remplacer les guides, les institutions ou les récits de terrain. Il est de rendre les bons repères plus accessibles, au bon moment et dans un format qui s’intègre naturellement à la visite.',
    talkingPoints: ['Distinguer voir un lieu et le comprendre', 'Le contexte est souvent dispersé', 'SafarOne complète les ressources existantes, sans prétendre les remplacer'],
    notesPrompt: 'Donner un exemple concret de découverte interrompue par la recherche d’information.',
  },
  {
    slideId: 7,
    script: 'Du côté de l’hôtel, l’expérience client ne s’arrête pas au comptoir d’accueil. Les équipes peuvent difficilement connaître chaque détail de tous les lieux, événements et expériences du territoire. Les informations sont parfois dispersées, et le client poursuit son séjour au-delà de l’établissement. SafarOne propose d’explorer une porte d’entrée numérique simple vers la découverte locale. Ce besoin devra être confirmé avec les hôteliers.',
    talkingPoints: ['L’accueil doit pouvoir se prolonger dans la destination', 'Les équipes ne peuvent pas tout connaître ni tout actualiser', 'Besoin à valider avec les établissements'],
    notesPrompt: 'Demander aux hôteliers présents quelles questions leurs clients posent le plus souvent.',
  },
  {
    slideId: 8,
    script: 'SafarOne est un compagnon de découverte touristique. Dans les écrans que nous allons vous montrer, on retrouve la découverte de lieux, l’accès à des fiches, une interaction audio et des pistes vers des événements ou des acteurs locaux. Nous souhaitons que ces gestes forment une expérience cohérente, plutôt qu’une suite de recherches isolées. Les captures viennent du support produit transmis par l’équipe.',
    talkingPoints: ['Définir le produit en une phrase', 'Citer seulement les parcours visibles dans les écrans fournis', 'Signaler que la démonstration repose sur les captures existantes'],
    notesPrompt: 'Préparer la transition vers le parcours en quatre étapes.',
  },
  {
    slideId: 9,
    script: 'Le parcours se résume en quatre mots : Discover, Listen, Explore, Experience. D’abord, je découvre ce qui se trouve autour de moi. Ensuite, j’écoute une histoire ou j’engage une interaction. Je peux explorer les informations liées au lieu, puis prolonger ma visite par un événement ou une adresse locale. Ce parcours est notre manière de relier la carte, le contenu et la vie de la destination.',
    talkingPoints: ['DISCOVER : repérer', 'LISTEN : écouter ou dialoguer', 'EXPLORE : approfondir', 'EXPERIENCE : vivre une activité locale'],
    notesPrompt: 'Faire répéter les quatre étapes à l’audience si cela aide la mémorisation.',
  },
  {
    slideId: 10,
    script: 'La première étape est la découverte autour de soi. La capture d’écran montre une expérience de découverte associée à Agadir, avec des lieux que l’on peut consulter. L’intérêt, pour le visiteur, est de transformer une position ou une envie en prochaine étape possible. La géolocalisation doit toujours rester au service du choix du visiteur et être utilisée de façon transparente.',
    talkingPoints: ['Présenter l’écran de découverte fourni', 'Expliquer le rôle de la proximité dans le parcours', 'Ne pas revendiquer de précision technique non documentée'],
    notesPrompt: 'Si une démonstration live existe le jour J, montrer la navigation sans données personnelles.',
  },
  {
    slideId: 11,
    script: 'La deuxième étape, c’est Listen. L’interface fournie présente une possibilité de dialogue vocal. Cela répond à une situation simple : le visiteur a une question pendant qu’il regarde le lieu, et il peut vouloir écouter plutôt que lire un long texte. Nous voulons rendre ce moment plus naturel. En revanche, une interface ne suffit pas à démontrer la qualité ou l’origine d’un modèle d’intelligence artificielle.',
    talkingPoints: ['Montrer uniquement ce que l’écran permet d’observer', 'Audio comme mode d’interaction', 'Ne pas confondre cette interface avec un modèle national spécialisé'],
    notesPrompt: 'Préparer une réponse claire sur ce qui fonctionne aujourd’hui dans la version présentée.',
  },
  {
    slideId: 12,
    script: 'La troisième étape permet d’explorer. Une fiche de lieu peut réunir son nom, sa localisation, une description et des éléments historiques. L’objectif est de donner au visiteur un point d’entrée fiable, puis de lui permettre d’approfondir. La confiance dépendra de la provenance des informations, de leur mise à jour et de la manière dont les contenus sont validés.',
    talkingPoints: ['Décrire les éléments visibles dans la fiche', 'Souligner l’importance des sources et de la mise à jour', 'Ne pas certifier le contenu de démonstration au-delà de ce qui est visible'],
    notesPrompt: 'Ajouter une source de contenu vérifiée pour une fiche, si disponible au lancement.',
  },
  {
    slideId: 13,
    script: 'Enfin, Experience relie la découverte à la vie locale. Les captures que vous allez voir montrent une fiche d’événement et une fiche d’établissement. Elles illustrent une direction produit : aider le visiteur à trouver des choses à faire et des acteurs à découvrir. Elles ne signifient pas que les organisations affichées sont partenaires de SafarOne ou qu’un partenariat commercial a déjà été signé.',
    talkingPoints: ['Présenter les deux types de fiche', 'Relier découverte numérique et expérience physique', 'Clarifier que les exemples d’écran ne prouvent aucune relation commerciale'],
    notesPrompt: 'Citer un type d’acteur local à inviter dans un futur pilote.',
  },
  {
    slideId: 14,
    script: 'Voici les deux premières étapes du parcours sur les captures fournies. D’abord, l’écran de découverte propose des lieux. Ensuite, la fiche donne davantage de contexte sur un site. Ce qui compte est la continuité entre les deux : une personne n’est pas obligée de recommencer sa recherche pour comprendre ce qu’elle vient de trouver. Les éléments chiffrés ou avis visibles dans la maquette ne sont pas repris comme preuves d’usage.',
    talkingPoints: ['Capture 1 : découverte', 'Capture 2 : fiche de lieu', 'Les valeurs affichées dans les maquettes ne constituent pas des statistiques vérifiées'],
    notesPrompt: 'Faire une pause pour laisser observer les deux captures.',
  },
  {
    slideId: 15,
    script: 'Sur cette capture, on voit la proposition d’interaction audio. Pour nous, l’audio peut accompagner le déplacement et permettre une expérience plus directe. Nous devons continuer à travailler la qualité du dialogue, la fiabilité des réponses et la clarté de ce qui est automatisé. Le projet Moroccan Tourism AI, que nous évoquerons plus tard, reste une proposition de recherche à construire : ce n’est pas un modèle achevé.',
    talkingPoints: ['Présenter le visuel sans promettre des capacités invisibles', 'Qualité et fiabilité restent des exigences', 'Le projet IA spécialisé est une piste future'],
    notesPrompt: 'Indiquer précisément quelles fonctions audio peuvent être montrées en direct.',
  },
  {
    slideId: 16,
    script: 'Ces deux écrans illustrent comment on peut prolonger la visite : par une fiche d’événement ou par une adresse locale. C’est précisément le type de parcours qui peut intéresser les hôtels et les partenaires de destination. Pour éviter toute ambiguïté, les noms, visuels, évaluations ou chiffres de la maquette ne sont pas utilisés ici comme preuve de partenariat ou de fréquentation.',
    talkingPoints: ['Événement culturel', 'Acteur local', 'Captures démonstratives, pas preuve de partenariat ni de métriques'],
    notesPrompt: 'Préparer une transition vers la valeur pour les visiteurs et le territoire.',
  },
  {
    slideId: 17,
    script: 'Pour un visiteur, l’intérêt attendu est de moins chercher et de mieux comprendre. SafarOne rassemble des repères pour découvrir, des contenus pour contextualiser et des pistes pour continuer la visite. Chacun peut avancer à son rythme : consulter une carte, lire une fiche, écouter ou regarder les expériences proposées. Ce sont des bénéfices visés qui devront être évalués auprès des utilisateurs.',
    talkingPoints: ['Repérage plus simple', 'Compréhension plus riche', 'Parcours à son propre rythme', 'Bénéfices attendus à mesurer'],
    notesPrompt: 'Ajouter un retour d’utilisateur seulement s’il a été collecté et peut être cité.',
  },
  {
    slideId: 18,
    script: 'Pour une agence de voyages, la relation avec le client ne devrait pas s’arrêter au moment où le séjour est vendu. Une fois sur place, le voyageur continue à chercher des repères, des informations et des expériences. Collecter et actualiser ces informations peut demander du temps. SafarOne souhaite prolonger le conseil de l’agence pendant le séjour, avec un compagnon de découverte. C’est une proposition à construire avec les agences, pas un service déjà déployé chez elles.',
    talkingPoints: ['Prolonger la relation au-delà de la vente', 'Faciliter l’accès aux informations locales pendant le séjour', 'Ouvrir la discussion sur un partenariat pilote'],
    notesPrompt: 'Illustrer avec une question fréquente d’un voyageur après son arrivée.',
  },
  {
    slideId: 19,
    script: 'Pour un hôtel, SafarOne peut être envisagé comme une extension de l’accueil. L’hôtel connaît les questions que se posent ses clients : où aller, quoi voir, comment comprendre la destination. Une porte d’entrée numérique pourrait les aider à explorer après le check-in. L’idée commerciale est à discuter avec les établissements ; nous ne présentons aujourd’hui aucun hôtel comme client ou partenaire confirmé.',
    talkingPoints: ['Cadrer le besoin d’hospitalité', 'Présenter SafarOne comme une piste à explorer', 'Pas de client ou contrat hôtelier annoncé'],
    notesPrompt: 'S’adresser directement aux responsables d’hôtels présents.',
  },
  {
    slideId: 20,
    script: 'Voici le concept d’accès hôtelier proposé : un compte hôtel, un solde de crédits, un accès par QR code, puis l’expérience du client. Ce schéma donne une structure à la discussion, pas un tarif ou une offre déjà en vente. Il faudra déterminer ensemble qui finance les crédits, comment ils sont consommés, combien de temps ils restent valables et quels contenus sont accessibles.',
    talkingPoints: ['Compte hôtel', 'Solde de crédits', 'QR code d’accès', 'Expérience client', 'Tous les paramètres commerciaux restent à définir'],
    notesPrompt: 'S’il y a une proposition de modèle déjà travaillée, préciser qu’elle est encore indicative.',
  },
  {
    slideId: 21,
    script: 'Les bénéfices potentiels pour un hôtel sont une expérience client plus singulière, une meilleure mise en valeur de la destination et un lien plus direct avec les acteurs locaux. Il faut rester prudent : ces bénéfices ne sont pas encore mesurés. Un pilote devrait commencer par des objectifs simples, des retours clients et des critères clairs avant toute décision d’extension.',
    talkingPoints: ['Différencier l’accueil', 'Valoriser la destination et le local', 'Mesurer l’intérêt avant d’étendre'],
    notesPrompt: 'Prévoir les questions à poser aux hôteliers sur leurs objectifs de séjour.',
  },
  {
    slideId: 22,
    script: 'La proposition aux hôtels est de commencer petit. Nous pouvons choisir ensemble un cas d’usage, cadrer le parcours et les règles d’accès, puis tester auprès d’un groupe limité de clients. Après cette expérimentation, l’hôtel et SafarOne décideront à partir des retours s’il faut poursuivre. La prochaine étape n’est pas une signature : c’est une réunion de cadrage pour définir si un pilote a du sens.',
    talkingPoints: ['Échange exploratoire', 'Choix d’un cas d’usage', 'Conception des règles d’accès', 'Test limité puis décision sur la suite'],
    notesPrompt: 'Inviter les managers intéressés à demander un rendez-vous après la présentation.',
  },
  {
    slideId: 23,
    script: 'Nous souhaitons construire la suite avec les professionnels du tourisme et les acteurs du territoire. Les hôtels peuvent tester une porte d’entrée vers la découverte locale. Les agences peuvent prolonger le conseil pendant le séjour. Les institutions, les acteurs culturels, la recherche et la formation peuvent contribuer à la qualité des contenus et à la compréhension des besoins. Ce sont des pistes de dialogue, pas des partenariats déjà conclus.',
    talkingPoints: ['Hôtels : accueil enrichi et cas pilote', 'Agences : continuité du conseil pendant le séjour', 'Institutions, culture et recherche : contenus et expertise', 'Aucun partenariat n’est annoncé comme acquis'],
    notesPrompt: 'Inviter les responsables intéressés à échanger après la présentation.',
  },
  {
    slideId: 24,
    script: 'Nous avons une direction de recherche que nous appelons Moroccan Tourism AI Initiative. Le mot important ici est “proposition”. Nous ne présentons pas de modèle national spécialisé déjà réalisé. Nous proposons plutôt de commencer par les bases : trouver les sources pertinentes, structurer les connaissances touristiques et culturelles, puis évaluer des usages utiles pour les visiteurs.',
    talkingPoints: ['Initiative de R&D proposée', 'Pas de modèle spécialisé réalisé annoncé', 'Priorité aux sources et aux connaissances'],
    notesPrompt: 'Répondre clairement aux questions sur le statut actuel des fonctions IA.',
  },
  {
    slideId: 25,
    script: 'Cette feuille de route de recherche est volontairement progressive. D’abord, qualifier les sources. Ensuite, étudier comment structurer les connaissances par lieu et par thème. Puis, évaluer des usages qui répondent à de vraies questions de visiteurs. Ce n’est qu’après ces étapes qu’il serait pertinent d’étudier un modèle spécialisé. Nous voulons une ambition sérieuse, fondée sur la qualité et la faisabilité.',
    talkingPoints: ['Sources', 'Structuration', 'Évaluation des usages', 'Faisabilité d’un modèle à long terme'],
    notesPrompt: 'Ajouter les premières pistes de collaboration scientifique seulement si elles sont confirmées.',
  },
  {
    slideId: 26,
    script: 'Le contexte national est particulièrement dynamique. Le ministère marocain du Tourisme a indiqué 19,8 millions d’arrivées touristiques en 2025, soit une progression de 14 % par rapport à 2024. Pour visualiser l’évolution, nous comparons avec les 17,4 millions d’arrivées observées en 2024, également publiées par le ministère. Ces données décrivent le tourisme national, pas l’usage de SafarOne.',
    talkingPoints: ['17,4 millions d’arrivées en 2024', '19,8 millions d’arrivées en 2025', '+14 % par rapport à 2024 · source : ministère du Tourisme'],
    notesPrompt: 'Mentionner la source affichée sur la diapositive.',
  },
  {
    slideId: 27,
    script: 'Deux autres chiffres permettent de lire l’activité touristique en 2024. Les recettes touristiques ont atteint 112 milliards de dirhams et les établissements d’hébergement classés ont enregistré 28,7 millions de nuitées. Les sources sont le ministère du Tourisme et sa page officielle des chiffres clés. Ces données montrent à la fois la dimension économique et la durée des séjours.',
    talkingPoints: ['112 milliards MAD de recettes en 2024', '28,7 millions de nuitées en hébergement classé en 2024', 'Source : page officielle des chiffres clés du ministère'],
    notesPrompt: 'Préciser que les années et sources figurent sous chaque indicateur.',
  },
  {
    slideId: 28,
    script: 'Il faut distinguer ces résultats observés des objectifs nationaux. La feuille de route 2023–2026 vise 200 000 emplois supplémentaires et 120 milliards de dirhams de recettes en devises à l’horizon 2026. Le ministère porte aussi l’ambition de 26 millions de touristes à l’horizon 2030. Ce sont des cibles stratégiques publiques, pas des résultats que SafarOne revendique.',
    talkingPoints: ['200 000 emplois supplémentaires visés en 2026', '120 milliards MAD de recettes en devises visés en 2026', '26 millions de touristes : ambition nationale pour 2030'],
    notesPrompt: 'Insister sur le libellé objectif / ambition et les horizons différents.',
  },
  {
    slideId: 29,
    script: 'La Coupe du Monde de la FIFA 2030 sera coorganisée par le Maroc, l’Espagne et le Portugal. Au-delà de la visibilité, elle peut accroître le besoin de repères multilingues et d’expériences touristiques accessibles. La FIFA a cité Agadir parmi les villes candidates pour des visites de sélection des sites en 2026. La sélection finale des sites et l’organisation de matchs à Agadir ne sont pas annoncées dans cette présentation.',
    talkingPoints: ['Pays hôtes : Maroc, Espagne, Portugal', 'Agadir figure parmi les villes candidates citées pour les visites de sélection', 'Aucune affirmation sur une sélection finale ou un match à Agadir'],
    notesPrompt: 'Citer la FIFA et la date de publication du 27 octobre 2026 sur les visites.',
  },
  {
    slideId: 30,
    script: 'Nous arrivons maintenant au chapitre stratégique SafarOne 2030. Notre formule est “From Agadir to Morocco, from Morocco to the world.” Il s’agit d’une ambition entrepreneuriale indépendante, pas d’un programme national ni d’un engagement gouvernemental. Nous voulons expliquer comment cette ambition pourrait se construire par étapes, à condition de valider le produit et de bâtir des partenariats solides.',
    talkingPoints: ['Présenter le chapitre SAFARONE 2030', 'Slogan officiel du chapitre', 'Clarifier le statut indépendant et proposé'],
    notesPrompt: 'Faire une courte pause avant la feuille de route.',
  },
  {
    slideId: 31,
    script: 'Notre feuille de route proposée commence par la fondation à Agadir en 2026. En 2027, nous voulons renforcer Souss-Massa. En 2028, envisager l’expansion aux grandes destinations et régions culturelles. En 2029, élargir les contenus, les langues et les partenariats. Puis, en 2030, viser une couverture nationale. Chaque étape dépendra du produit, des ressources et de l’intérêt des partenaires.',
    talkingPoints: ['2026 : fondation et validation', '2027 : Souss-Massa', '2028–2029 : expansion et réseau', '2030 : ambition nationale, non garantie'],
    notesPrompt: 'Adapter les jalons si des décisions d’entreprise ont été prises depuis la rédaction.',
  },
  {
    slideId: 32,
    script: 'Le Maroc se prépare à accueillir le monde. SafarOne veut aider le monde à découvrir le Maroc. Notre ambition ne se limite pas au tournoi : nous souhaitons contribuer à un écosystème numérique durable qui relie les visiteurs aux destinations, au patrimoine, aux histoires et aux entreprises locales. Depuis Agadir, nous voulons construire une vision marocaine ouverte sur le monde, avec les partenaires qui décideront de nous rejoindre.',
    talkingPoints: ['Prononcer les deux phrases clés', 'La valeur doit durer au-delà de la Coupe du Monde', 'Relier destinations, patrimoine, récits et entreprises locales'],
    notesPrompt: 'Terminer le chapitre par une pause, puis reprendre les deux phrases finales visibles à l’écran.',
  },
  {
    slideId: 33,
    script: 'Nous souhaitons maintenant ouvrir la discussion avec celles et ceux qui veulent tester, enrichir ou accompagner cette expérience. Hôtels et agences de voyages peuvent nous aider à définir un premier cas d’usage. Les acteurs du tourisme, de la culture et des territoires peuvent contribuer à la qualité des contenus et des expériences. La prochaine étape est une rencontre exploratoire, sans présumer d’un accord avant de l’avoir construit ensemble.',
    talkingPoints: ['Proposer un échange concret après l’événement', 'Identifier les acteurs intéressés par un pilote', 'Définir les prochaines étapes avec chaque partenaire'],
    notesPrompt: 'Préciser comment les invités peuvent vous contacter après la présentation.',
  },
  {
    slideId: 34,
    script: 'Ce soir, à Agadir, nous déclarons SafarOne officiellement lancé. Ce lancement marque le début d’un travail à poursuivre : apprendre du terrain, enrichir le produit et construire des relations de confiance avec les acteurs touristiques. Nous sommes fiers de commencer depuis le Maroc et de concevoir une expérience tournée vers le monde. Merci de faire partie de cette première étape. Lançons SafarOne.',
    talkingPoints: ['Date et lieu du lancement', 'Le lancement ouvre la suite du travail', 'Inviter à la séquence de compte à rebours'],
    notesPrompt: 'Appuyer sur LANCER SAFARONE au moment prévu par la mise en scène.',
  },
];
