export type SlideKind =
  | 'cover'
  | 'statement'
  | 'story'
  | 'founders'
  | 'acknowledgement'
  | 'split'
  | 'journey'
  | 'feature'
  | 'demo'
  | 'impact'
  | 'hotel'
  | 'flow'
  | 'partners'
  | 'research'
  | 'stats'
  | 'worldcup'
  | 'chapter'
  | 'timeline'
  | 'vision'
  | 'invitation'
  | 'launch';

export type SlideItem = {
  title: string;
  body: string;
  label?: string;
};

export type SlideStat = {
  value: string;
  label: string;
  year: string;
  status: 'observed' | 'target';
  source: string;
  sourceUrl: string;
  chartValue?: number;
};

export type SlideImage = {
  src: string;
  alt: string;
  label: string;
};

export type PresentationSlide = {
  id: number;
  chapter: string;
  kind: SlideKind;
  kicker: string;
  title: string;
  subtitle?: string;
  body?: string;
  quote?: string;
  items?: SlideItem[];
  images?: SlideImage[];
  stats?: SlideStat[];
  sourceNote?: string;
  statusNote?: string;
  slogan?: string;
  secondarySlogan?: string;
  closingLines?: string[];
};

const originalSlides: PresentationSlide[] = [
  {
    id: 1,
    chapter: 'Ouverture',
    kind: 'cover',
    kicker: 'LANCEMENT OFFICIEL · 15 DÉCEMBRE 2026 · AGADIR',
    title: 'SAFARONE',
    subtitle: 'Un nouveau compagnon pour découvrir le Maroc.',
    slogan: 'BEYOND PLACES. INTO STORIES.',
    secondarySlogan: 'A New Chapter in Intelligent Tourism.',
    body: 'Cité de l’Innovation Souss-Massa · Agadir · Maroc',
  },
  {
    id: 2,
    chapter: 'Ouverture',
    kind: 'statement',
    kicker: 'NOTRE PHILOSOPHIE',
    title: 'BEYOND PLACES. INTO STORIES.',
    subtitle: 'Aller au-delà du lieu. Entrer dans son histoire.',
    body: 'Une destination ne se résume ni à une épingle sur une carte ni à une photographie. SafarOne veut rapprocher le visiteur du contexte, des récits et des expériences qui donnent du sens à un lieu.',
  },
  {
    id: 3,
    chapter: 'Origines',
    kind: 'story',
    kicker: 'À L’ORIGINE DU PROJET',
    title: 'Une idée née à Agadir.',
    subtitle: 'Une carte vous dit où. Une histoire vous aide à comprendre pourquoi.',
    body: 'SafarOne part d’une question simple : comment rendre plus accessibles les histoires d’un territoire à celles et ceux qui le visitent ? Le projet prend forme à Agadir, avec l’ambition de relier découverte, contenu documenté et vie locale.',
    items: [
      { title: 'Un besoin concret', body: 'Le visiteur repère un lieu, mais manque parfois de contexte pour en saisir la portée.' },
      { title: 'Un point de départ', body: 'Agadir et Souss-Massa offrent le premier terrain de lancement et de validation du projet.' },
      { title: 'Une ambition ouverte', body: 'Construire avec les acteurs du tourisme, de la culture et de l’hospitalité.' },
    ],
  },
  {
    id: 4,
    chapter: 'Origines',
    kind: 'founders',
    kicker: 'LES FONDATEURS',
    title: 'Un projet porté par deux fondateurs.',
    subtitle: 'Une vision produit et une direction technique au service d’une même ambition.',
    items: [
      { title: 'Khalid EL KRAZBA', body: 'Co-Founder & CEO', label: 'VISION · DIRECTION GÉNÉRALE' },
      { title: 'Hayat IDBIHI', body: 'Co-Founder & CTO', label: 'TECHNOLOGIE · DIRECTION TECHNIQUE' },
    ],
  },
  {
    id: 5,
    chapter: 'Origines',
    kind: 'acknowledgement',
    kicker: 'THE FIRST BELIEVER AWARD',
    title: 'Merci, Monsieur Rachid El Maayfi.',
    subtitle: 'Un soutien concret au commencement de l’aventure.',
    body: 'Il a pris en charge les frais de création de HK Solutions SARL, la société qui porte SafarOne. Les fondateurs lui adressent leur profonde reconnaissance pour ce soutien apporté à l’origine du projet.',
    statusNote: 'Reconnaissance exprimée par les fondateurs dans le support initial.',
  },
  {
    id: 6,
    chapter: 'Le constat',
    kind: 'split',
    kicker: 'LE DÉFI DU VISITEUR',
    title: 'Voir un lieu ne suffit pas à en saisir le sens.',
    subtitle: 'L’information existe, mais elle est souvent dispersée au moment où l’on en a besoin.',
    items: [
      { title: 'Ce que l’on voit', body: 'Une adresse, un panorama, un monument ou une rue animée.' },
      { title: 'Ce qui manque parfois', body: 'Le contexte historique, les récits locaux et des pistes fiables pour aller plus loin.' },
      { title: 'Ce que cherche le visiteur', body: 'Comprendre sans interrompre sa découverte, dans une langue et un format accessibles.' },
    ],
  },
  {
    id: 7,
    chapter: 'Le constat',
    kind: 'impact',
    kicker: 'LE DÉFI DE L’HÔTEL',
    title: 'L’accueil s’arrête parfois à la porte de l’établissement.',
    subtitle: 'Le séjour se poursuit dans une destination que le client doit encore apprendre à explorer.',
    items: [
      { title: 'Orienter sans tout connaître', body: 'Les équipes d’accueil ne peuvent pas toujours détailler chaque lieu, événement ou expérience locale.' },
      { title: 'Des informations dispersées', body: 'Les recommandations, horaires et contenus utiles peuvent être répartis entre plusieurs supports.' },
      { title: 'Prolonger l’expérience', body: 'L’hôtel cherche des façons simples d’accompagner le client au-delà des services sur place.' },
    ],
    statusNote: 'Enjeux à confronter aux besoins des établissements lors des échanges et d’un éventuel pilote.',
  },
  {
    id: 8,
    chapter: 'La réponse SafarOne',
    kind: 'story',
    kicker: 'QU’EST-CE QUE SAFARONE ?',
    title: 'Un compagnon de découverte touristique.',
    subtitle: 'Trois publics, un même besoin : relier le voyageur aux bonnes informations et expériences, au bon moment.',
    body: 'SafarOne répond à cet enjeu avec un compagnon de découverte qui réunit une carte géolocalisée, des fiches et contenus sur les lieux, une interaction audio, ainsi que des informations sur des événements et des acteurs locaux. Le produit est présenté ici à partir des écrans fournis par l’équipe.',
    items: [
      { title: 'Découvrir', body: 'Repérer des lieux d’intérêt à proximité et choisir où commencer.' },
      { title: 'Écouter', body: 'Accéder à une interaction audio autour d’un lieu ou d’une question.' },
      { title: 'Explorer', body: 'Approfondir avec des informations et récits liés à la destination.' },
      { title: 'Vivre', body: 'Repérer des événements et des acteurs locaux à explorer.' },
    ],
  },
  {
    id: 9,
    chapter: 'La réponse SafarOne',
    kind: 'journey',
    kicker: 'LE PARCOURS VISITEUR',
    title: 'DISCOVER → LISTEN → EXPLORE → EXPERIENCE',
    subtitle: 'Quatre gestes pour passer d’un repère sur la carte à une expérience vécue.',
    items: [
      { title: 'DISCOVER', body: 'Voir les lieux d’intérêt autour de soi et choisir une première étape.' },
      { title: 'LISTEN', body: 'Écouter une histoire et interagir par la voix au fil de la découverte.' },
      { title: 'EXPLORE', body: 'Approfondir les informations sur un lieu, son contexte et ses récits.' },
      { title: 'EXPERIENCE', body: 'Repérer des activités, événements et acteurs locaux à découvrir.' },
    ],
  },
  {
    id: 10,
    chapter: 'La réponse SafarOne',
    kind: 'feature',
    kicker: '01 · DISCOVER',
    title: 'La destination commence autour de vous.',
    subtitle: 'Une découverte géolocalisée qui aide à choisir où porter son attention.',
    body: 'L’écran de découverte fourni présente une carte et des suggestions de lieux autour d’Agadir. Le visiteur peut commencer par un point d’intérêt, puis ouvrir sa fiche pour en savoir davantage.',
    items: [
      { title: 'Se situer', body: 'Comprendre les lieux proches dans le contexte de la destination.' },
      { title: 'Choisir', body: 'Passer d’une liste de possibilités à un lieu qui attire sa curiosité.' },
      { title: 'Continuer', body: 'Ouvrir une fiche et poursuivre le parcours avec davantage de contexte.' },
    ],
    statusNote: 'Fonctionnalité montrée dans les captures de l’application fournies.',
  },
  {
    id: 11,
    chapter: 'La réponse SafarOne',
    kind: 'feature',
    kicker: '02 · LISTEN',
    title: 'Écouter pour entrer dans le récit.',
    subtitle: 'Une interaction audio pensée pour accompagner la visite, pas la remplacer.',
    body: 'La capture fournie montre une interface d’assistant et une entrée vers l’échange vocal. L’intention est de rendre la curiosité plus facile à suivre : poser une question, écouter et reprendre sa découverte.',
    items: [
      { title: 'Une voix en situation', body: 'Le visiteur peut dialoguer pendant son parcours plutôt que chercher ailleurs.' },
      { title: 'Un format complémentaire', body: 'L’audio accompagne l’observation du lieu et la lecture de ses informations.' },
      { title: 'Une exigence de confiance', body: 'La qualité des réponses et des sources doit rester un chantier produit prioritaire.' },
    ],
    statusNote: 'La capture d’interface ne constitue pas une preuve de modèle d’IA touristique spécialisé.',
  },
  {
    id: 12,
    chapter: 'La réponse SafarOne',
    kind: 'feature',
    kicker: '03 · EXPLORE',
    title: 'Approfondir sans perdre le fil de la visite.',
    subtitle: 'Des fiches de lieux et des informations documentées pour donner du contexte.',
    body: 'Une fiche peut rassembler une description, des repères pratiques et un récit de lieu. L’objectif est de permettre au visiteur de passer de la découverte visuelle à une compréhension plus riche, à son rythme.',
    items: [
      { title: 'Un lieu identifié', body: 'Nom et localisation visibles pour situer le sujet.' },
      { title: 'Un contexte à lire', body: 'Description et contenu historique associés à la destination.' },
      { title: 'Des informations à fiabiliser', body: 'Les contenus doivent s’appuyer sur des sources et une validation adaptées.' },
    ],
    statusNote: 'Les textes et indicateurs visibles dans les captures de démonstration ne sont pas certifiés par cette présentation.',
  },
  {
    id: 13,
    chapter: 'La réponse SafarOne',
    kind: 'feature',
    kicker: '04 · EXPERIENCE',
    title: 'La découverte se prolonge dans la vie locale.',
    subtitle: 'Des événements et des adresses peuvent devenir des étapes du séjour.',
    body: 'Les écrans fournis montrent des fiches d’événement et d’établissement local. Ils illustrent le type d’information que SafarOne souhaite rapprocher du visiteur lorsqu’il explore une destination.',
    items: [
      { title: 'Événements', body: 'Repérer une activité et consulter sa fiche pratique.' },
      { title: 'Acteurs locaux', body: 'Découvrir une adresse et comprendre ce qu’elle propose.' },
      { title: 'Une rencontre à construire', body: 'Les relations commerciales et partenariats restent à établir avec les acteurs concernés.' },
    ],
    statusNote: 'Les fiches de démonstration ne confirment ni clientèle, ni avis vérifiés, ni partenariat.',
  },
  {
    id: 14,
    chapter: 'Démonstration produit',
    kind: 'demo',
    kicker: 'DÉMONSTRATION · CAPTURES RÉELLES FOURNIES',
    title: 'Du lieu à sa fiche.',
    subtitle: 'Premier temps : découvrir des lieux, puis ouvrir le contexte associé.',
    images: [
      { src: '/demo/decouvrir.webp', alt: 'Capture SafarOne fournie : écran de découverte avec des lieux présentés autour d’Agadir.', label: '01 · DÉCOUVRIR' },
      { src: '/demo/comprendre.webp', alt: 'Capture SafarOne fournie : fiche de la Kasbah d’Agadir avec description et historique.', label: '02 · COMPRENDRE' },
    ],
    body: 'Ces captures proviennent du support SafarOne fourni. Elles montrent les écrans de découverte et de fiche de lieu ; elles ne valident pas les avis ou chiffres d’usage affichés dans la maquette.',
  },
  {
    id: 15,
    chapter: 'Démonstration produit',
    kind: 'demo',
    kicker: 'DÉMONSTRATION · INTERACTION AUDIO',
    title: 'Une question peut ouvrir une conversation.',
    subtitle: 'La capture montre l’interface audio proposée dans l’application.',
    images: [
      { src: '/demo/dialoguer.webp', alt: 'Capture SafarOne fournie : interface de dialogue avec une option d’interaction vocale.', label: '03 · DIALOGUER' },
    ],
    body: 'L’écran sert ici à expliquer l’intention d’usage : une interaction parlée au service de la découverte. Il ne permet pas de conclure qu’un modèle spécialisé Moroccan Tourism AI est déjà construit.',
    statusNote: 'Interface fournie par SafarOne · modèle touristique national spécialisé : proposition de R&D, non réalisé.',
  },
  {
    id: 16,
    chapter: 'Démonstration produit',
    kind: 'demo',
    kicker: 'DÉMONSTRATION · DESTINATION VIVANTE',
    title: 'Événements et adresses deviennent des pistes de visite.',
    subtitle: 'Les fiches locales illustrent comment poursuivre l’exploration au-delà des monuments.',
    images: [
      { src: '/demo/evenement.webp', alt: 'Capture SafarOne fournie : fiche d’un événement culturel à Agadir.', label: '04 · ÉVÉNEMENT' },
      { src: '/demo/acteur-local.webp', alt: 'Capture SafarOne fournie : fiche d’un établissement local près d’Agadir.', label: '05 · ACTEUR LOCAL' },
    ],
    body: 'Ces captures illustrent des formats de fiches. Les établissements et les contenus affichés dans les maquettes ne sont pas présentés comme partenaires officiels ou déploiements confirmés.',
  },
  {
    id: 17,
    chapter: 'Valeur créée',
    kind: 'impact',
    kicker: 'POUR LES VISITEURS',
    title: 'Moins de recherche dispersée. Plus de présence sur place.',
    subtitle: 'SafarOne veut aider chaque visiteur à transformer sa curiosité en parcours.',
    items: [
      { title: 'Se repérer', body: 'Découvrir des lieux proches en tenant compte de la destination visitée.' },
      { title: 'Comprendre', body: 'Accéder à des récits et informations qui donnent du contexte.' },
      { title: 'Choisir son rythme', body: 'Alterner carte, lecture, écoute et découverte sur le terrain.' },
      { title: 'Aller plus loin', body: 'Trouver des événements et expériences locales à explorer.' },
    ],
    statusNote: 'Bénéfices attendus de l’expérience produit, sans mesure d’impact publiée à ce jour.',
  },
  {
    id: 18,
    chapter: 'Le constat',
    kind: 'impact',
    kicker: 'LE DÉFI DE L’AGENCE DE VOYAGES',
    title: 'Le conseil ne devrait pas s’arrêter à la réservation du séjour.',
    subtitle: 'Une fois sur place, le voyageur a encore besoin de repères fiables pour vivre la destination.',
    items: [
      { title: 'Après la vente', body: 'L’agence dispose de peu de continuité numérique pour accompagner le client pendant son séjour.' },
      { title: 'Conseils difficiles à actualiser', body: 'Les informations sur les lieux, événements et acteurs locaux demandent du temps à collecter et à maintenir.' },
      { title: 'Valoriser son expertise', body: 'Un compagnon de découverte peut prolonger le conseil de l’agence et enrichir l’expérience du voyageur.' },
    ],
    statusNote: 'Problématiques à valider avec les agences partenaires potentielles ; elles ne constituent pas une étude sectorielle.',
  },
  {
    id: 19,
    chapter: 'Hôtellerie',
    kind: 'hotel',
    kicker: 'UNE OPPORTUNITÉ COMMERCIALE À EXPLORER',
    title: 'Prolonger l’accueil jusque dans la destination.',
    subtitle: 'À l’hôtel, SafarOne peut devenir une invitation à découvrir davantage autour du séjour.',
    body: 'Le personnel ou les supports d’accueil présentent une porte d’entrée simple vers la découverte locale. Le client choisit ensuite ce qui l’intéresse : lieux, récits, activités ou événements.',
    items: [
      { title: 'Avant de sortir', body: 'Le visiteur repère une idée et consulte des informations sur la destination.' },
      { title: 'Pendant la visite', body: 'Il poursuit l’exploration par une fiche, une interaction audio ou une activité locale.' },
      { title: 'Pour l’hôtel', body: 'L’établissement teste une nouvelle façon d’enrichir l’expérience du séjour.' },
    ],
    statusNote: 'Proposition commerciale à discuter : aucun hôtel partenaire n’est confirmé.',
  },
  {
    id: 20,
    chapter: 'Hôtellerie',
    kind: 'flow',
    kicker: 'CONCEPT D’ACCÈS HÔTELIER · MODÈLE PROPOSÉ',
    title: 'Compte hôtel → Crédit → QR → Expérience client.',
    subtitle: 'Un parcours de principe, dont les règles commerciales restent à définir ensemble.',
    items: [
      { title: '1 · Compte hôtel', body: 'L’établissement dispose d’un espace partenaire si le modèle est validé.' },
      { title: '2 · Solde de crédits', body: 'Des crédits sont ajoutés selon une formule et des conditions à convenir.' },
      { title: '3 · Accès QR', body: 'Un QR code présenté par l’hôtel donne accès au parcours défini pour le pilote.' },
      { title: '4 · Expérience client', body: 'Le visiteur découvre les contenus et expériences retenus pour la destination.' },
    ],
    statusNote: 'Concept en discussion : prix, volume, règles de consommation, durée et modalités techniques non définis.',
  },
  {
    id: 21,
    chapter: 'Hôtellerie',
    kind: 'impact',
    kicker: 'CE QUE L’HÔTEL PEUT Y GAGNER',
    title: 'Une expérience différenciante, ancrée dans le territoire.',
    subtitle: 'La valeur du pilote sera à évaluer avec les hôteliers, à partir des besoins de leurs clients.',
    items: [
      { title: 'Un accueil enrichi', body: 'Proposer aux clients une porte d’entrée vers la destination.' },
      { title: 'Un service plus singulier', body: 'Ajouter une dimension de découverte aux informations de séjour.' },
      { title: 'Un lien local', body: 'Mettre en avant des récits et expériences retenus avec les acteurs concernés.' },
      { title: 'Un test mesurable', body: 'Définir ensemble des indicateurs d’intérêt et de satisfaction avant un pilote.' },
    ],
    statusNote: 'Bénéfices potentiels à valider : ils ne sont pas présentés comme des résultats prouvés.',
  },
  {
    id: 22,
    chapter: 'Hôtellerie',
    kind: 'hotel',
    kicker: 'INVITATION AUX HÔTELS · PREMIER PILOTE',
    title: 'Commencer par un cas d’usage simple.',
    subtitle: 'Un pilote doit répondre à un besoin réel du client et être assez léger pour apprendre rapidement.',
    items: [
      { title: '1 · Échanger', body: 'Choisir un hôtel et un profil de séjour à servir en priorité.' },
      { title: '2 · Cadrer', body: 'Définir le contenu, le parcours QR, les crédits éventuels et les règles d’accès.' },
      { title: '3 · Tester', body: 'Lancer une expérimentation limitée avec des retours clients et équipe.' },
      { title: '4 · Décider', body: 'Évaluer les retours avant d’envisager une suite ou un élargissement.' },
    ],
    body: 'Prochaine étape proposée aux responsables hôteliers : un rendez-vous exploratoire pour choisir un cas d’usage et dessiner ensemble les contours d’un pilote.',
    statusNote: 'Programme proposé, pas un déploiement ou contrat existant.',
  },
  {
    id: 23,
    chapter: 'Partenariats',
    kind: 'partners',
    kicker: 'COLLABORATION AVEC LE TERRITOIRE',
    title: 'La suite se construit avec les acteurs locaux.',
    subtitle: 'SafarOne est une initiative entrepreneuriale indépendante qui souhaite ouvrir le dialogue avec les professionnels du voyage et du territoire.',
    items: [
      { title: 'Hôtellerie', body: 'Explorer un accueil client enrichi et des accès QR dans le cadre d’un pilote.' },
      { title: 'Agences de voyages', body: 'Prolonger le conseil avant et pendant le séjour avec un compagnon de découverte.' },
      { title: 'Institutions touristiques', body: 'Identifier des contenus fiables et des enjeux communs de découverte.' },
      { title: 'Culture et patrimoine', body: 'Échanger sur la transmission des histoires et la qualité des récits.' },
      { title: 'Recherche et formation', body: 'Étudier des pistes de structuration des connaissances touristiques marocaines.' },
    ],
    statusNote: 'Partenariats à construire. SafarOne n’est pas présenté comme initiative gouvernementale ou plateforme officiellement endossée.',
  },
  {
    id: 24,
    chapter: 'Recherche et vision',
    kind: 'research',
    kicker: 'MOROCCAN TOURISM AI INITIATIVE · PROPOSITION DE R&D',
    title: 'Une direction de recherche à explorer.',
    subtitle: 'Développer, à terme, une meilleure compréhension des connaissances touristiques marocaines.',
    body: 'L’initiative Moroccan Tourism AI est une proposition de recherche et développement, pas un modèle d’IA achevé. La première question est celle des connaissances : comment les documenter, les structurer et les relier à des sources adaptées ?',
    items: [
      { title: 'Documenter', body: 'Étudier les sources et informations touristiques et culturelles disponibles.' },
      { title: 'Structurer', body: 'Explorer des méthodes pour organiser les connaissances par lieu, thème et territoire.' },
      { title: 'Évaluer', body: 'Tester des usages pertinents avant toute décision de modèle spécialisé.' },
    ],
    statusNote: 'Ambition de R&D proposée · aucun modèle touristique national spécialisé n’est annoncé comme réalisé.',
  },
  {
    id: 25,
    chapter: 'Recherche et vision',
    kind: 'timeline',
    kicker: 'FEUILLE DE ROUTE DE RECHERCHE · PROPOSÉE',
    title: 'Une ambition scientifique, étape par étape.',
    subtitle: 'La priorité est la qualité des connaissances, pas la promesse prématurée d’un modèle.',
    items: [
      { title: '01 · Sources', body: 'Repérer et qualifier des sources fiables, pertinentes et réutilisables.' },
      { title: '02 · Connaissances', body: 'Étudier comment structurer des récits et informations de lieux.' },
      { title: '03 · Usages', body: 'Évaluer comment ces connaissances pourraient soutenir les questions des visiteurs.' },
      { title: '04 · Faisabilité', body: 'À plus long terme, étudier si un modèle spécialisé est justifié et réalisable.' },
    ],
    statusNote: 'Proposition de recherche à construire avec des partenaires ; les étapes ne sont pas des résultats acquis.',
  },
  {
    id: 26,
    chapter: 'Le Maroc en mouvement',
    kind: 'stats',
    kicker: 'LE TOURISME MAROCAIN · CHIFFRE OBSERVÉ',
    title: '19,8 millions d’arrivées touristiques.',
    subtitle: '+14 % par rapport à 2024.',
    stats: [
      {
        value: '17,4 M',
        label: 'arrivées touristiques au Maroc',
        year: '2024 · chiffre observé',
        status: 'observed',
        source: 'Ministère du Tourisme · Chiffres clés 2024',
        sourceUrl: 'https://mtaess.gov.ma/fr/key-figures/',
        chartValue: 17.4,
      },
      {
        value: '19,8 M',
        label: 'arrivées touristiques au Maroc',
        year: '2025 · chiffre observé',
        status: 'observed',
        source: 'Ministère du Tourisme · 9 janvier 2026',
        sourceUrl: 'https://mtaess.gov.ma/fr/tourisme-le-maroc-atteint-un-seuil-historique-de-pres-de-20-millions-de-touristes-en-2025',
        chartValue: 19.8,
      },
      {
        value: '+14 %',
        label: 'de croissance par rapport à 2024',
        year: '2025 · chiffre observé',
        status: 'observed',
        source: 'Ministère du Tourisme · 9 janvier 2026',
        sourceUrl: 'https://mtaess.gov.ma/fr/tourisme-le-maroc-atteint-un-seuil-historique-de-pres-de-20-millions-de-touristes-en-2025',
      },
    ],
    body: 'Un indicateur de l’élan touristique du Royaume. Il décrit une performance nationale passée ; il ne représente ni un chiffre d’usage SafarOne, ni une prévision propre à l’entreprise.',
  },
  {
    id: 27,
    chapter: 'Le Maroc en mouvement',
    kind: 'stats',
    kicker: 'LE TOURISME MAROCAIN · CHIFFRES OBSERVÉS',
    title: 'Un secteur qui relie séjour et retombées.',
    subtitle: 'Deux indicateurs nationaux publiés pour 2024.',
    stats: [
      {
        value: '112 Md',
        label: 'MAD de recettes touristiques',
        year: '2024 · chiffre observé',
        status: 'observed',
        source: 'Ministère du Tourisme · Chiffres clés 2024',
        sourceUrl: 'https://mtaess.gov.ma/fr/key-figures/',
      },
      {
        value: '28,7 M',
        label: 'de nuitées en établissements d’hébergement classés',
        year: '2024 · chiffre observé',
        status: 'observed',
        source: 'Ministère du Tourisme · Chiffres clés 2024',
        sourceUrl: 'https://mtaess.gov.ma/fr/key-figures/',
      },
    ],
    body: 'Les recettes et les nuitées donnent deux angles complémentaires sur l’activité touristique : la valeur économique enregistrée et la durée du séjour en hébergement classé.',
  },
  {
    id: 28,
    chapter: 'Le Maroc en mouvement',
    kind: 'stats',
    kicker: 'OBJECTIFS NATIONAUX · NE PAS CONFONDRE AVEC DES RÉSULTATS',
    title: 'Des caps fixés par la stratégie nationale.',
    subtitle: 'Deux horizons, deux catégories de cibles.',
    stats: [
      {
        value: '200 000',
        label: 'emplois supplémentaires visés par la feuille de route',
        year: 'Horizon 2026 · objectif',
        status: 'target',
        source: 'Ministère du Tourisme · Feuille de route 2023–2026',
        sourceUrl: 'https://mtaess.gov.ma/fr/tourisme/feuille-de-route/',
      },
      {
        value: '120 Md MAD',
        label: 'de recettes en devises visées par la feuille de route',
        year: 'Horizon 2026 · objectif',
        status: 'target',
        source: 'Ministère du Tourisme · Feuille de route 2023–2026',
        sourceUrl: 'https://mtaess.gov.ma/fr/tourisme/feuille-de-route/',
      },
      {
        value: '26 M',
        label: 'de touristes : ambition nationale',
        year: 'Horizon 2030 · objectif',
        status: 'target',
        source: 'Ministère du Tourisme · Feuille de route',
        sourceUrl: 'https://mtaess.gov.ma/fr/tourisme/feuille-de-route/',
      },
    ],
    body: 'Ces chiffres sont des objectifs publics nationaux : 200 000 emplois et 120 milliards de dirhams de recettes en devises à l’horizon 2026, puis 26 millions de touristes à l’horizon 2030. Ils ne sont pas présentés comme déjà atteints.',
  },
  {
    id: 29,
    chapter: 'Le Maroc en mouvement',
    kind: 'worldcup',
    kicker: 'COUPE DU MONDE DE LA FIFA 2030™',
    title: 'Une vitrine mondiale. Une opportunité durable.',
    subtitle: 'Le Maroc, l’Espagne et le Portugal coorganiseront la Coupe du Monde de la FIFA 2030™.',
    body: 'La visibilité internationale et l’accueil de visiteurs venus de nombreux pays peuvent accroître l’intérêt pour des expériences touristiques multilingues. L’enjeu pour SafarOne serait d’aider ces visiteurs à découvrir les destinations et les récits du pays au-delà des jours de match.',
    items: [
      { title: 'Visibilité accrue', body: 'Le Maroc se prépare à accueillir l’attention du monde entier.' },
      { title: 'Expériences multilingues', body: 'Les visiteurs auront besoin de repères compréhensibles dans plusieurs langues.' },
      { title: 'Économie locale', body: 'Hôtels, restaurants, lieux culturels et entreprises locales peuvent profiter d’une découverte mieux reliée.' },
      { title: 'Héritage touristique', body: 'L’occasion est de créer des expériences qui restent après le tournoi.' },
    ],
    statusNote: 'Agadir figure parmi les villes candidates citées par la FIFA pour les visites de sélection des sites annoncées le 27 octobre 2026. La sélection finale n’est pas présentée comme confirmée ; aucun match à Agadir n’est annoncé ici.',
    sourceNote: 'Sources : FIFA, nomination des pays hôtes (11 décembre 2024) et visites de sélection des villes candidates (27 octobre 2026).',
  },
  {
    id: 30,
    chapter: 'SafarOne 2030',
    kind: 'chapter',
    kicker: 'CHAPITRE STRATÉGIQUE',
    title: 'SAFARONE 2030',
    subtitle: 'FROM AGADIR TO MOROCCO, FROM MOROCCO TO THE WORLD.',
    body: 'Une ambition entrepreneuriale indépendante, pensée par étapes et ouverte aux partenaires du tourisme marocain.',
  },
  {
    id: 31,
    chapter: 'SafarOne 2030',
    kind: 'timeline',
    kicker: 'FEUILLE DE ROUTE SAFARONE · PROPOSITION 2026–2030',
    title: 'Un cap national, construit par étapes.',
    subtitle: 'Une vision de croissance proposée — pas un bilan d’avancement ni un engagement garanti.',
    items: [
      { title: '2026 · Fondation', body: 'Lancer à Agadir, nouer les premiers échanges et valider le produit sur le terrain.' },
      { title: '2027 · Développement régional', body: 'Renforcer la couverture de Souss-Massa et développer le réseau hôtelier et touristique.' },
      { title: '2028 · Expansion nationale', body: 'Étendre la plateforme aux principales destinations touristiques et régions culturelles du Maroc.' },
      { title: '2029 · Réseau national', body: 'Enrichir les destinations, contenus locaux, expériences multilingues et partenariats commerciaux.' },
      { title: '2030 · Ambition Maroc', body: 'Viser une couverture à l’échelle nationale et accompagner la découverte du Maroc pendant et après la Coupe du Monde.' },
    ],
    statusNote: 'Jalons stratégiques proposés par SafarOne. Ils restent soumis à la validation du produit, des partenariats et des ressources.',
  },
  {
    id: 32,
    chapter: 'SafarOne 2030',
    kind: 'vision',
    kicker: 'NOTRE MESSAGE STRATÉGIQUE',
    title: 'Morocco is preparing to welcome the world.',
    quote: 'SafarOne wants to help the world discover Morocco.',
    body: 'Notre ambition n’est pas simplement de profiter d’un événement mondial. Elle est de contribuer, avec les partenaires qui le souhaiteront, à un écosystème numérique durable reliant les visiteurs aux destinations, au patrimoine, aux histoires et aux entreprises locales.',
    items: [
      { title: 'DEPUIS AGADIR', body: 'Une initiative locale, portée par des entrepreneurs indépendants.' },
      { title: 'À L’ÉCHELLE DU MAROC', body: 'Une vision nationale qui devra se construire avec les territoires.' },
      { title: 'OUVERTE SUR LE MONDE', body: 'Des expériences de découverte pensées pour accueillir des visiteurs internationaux.' },
    ],
    statusNote: 'SafarOne n’est ni un partenaire officiel de la FIFA, ni une initiative gouvernementale, ni une plateforme bénéficiant d’un soutien national annoncé.',
    closingLines: [
      'FROM A LOCAL INITIATIVE IN AGADIR TO A NATIONAL TOURISM TECHNOLOGY VISION.',
      'OUR AMBITION: ALL OF MOROCCO BY 2030.',
    ],
  },
  {
    id: 33,
    chapter: 'Invitation',
    kind: 'invitation',
    kicker: 'L’INVITATION',
    title: 'Construisons la suite, ensemble.',
    subtitle: 'Une prochaine étape claire pour chaque partenaire intéressé.',
    items: [
      { title: 'Hôtels et agences de voyages', body: 'Ouvrir un échange exploratoire sur le parcours client et la possibilité d’un pilote.' },
      { title: 'Acteurs du tourisme et de la culture', body: 'Identifier les contenus et expériences qui méritent d’être mieux découverts.' },
      { title: 'Institutions, territoires et recherche', body: 'Discuter des sources, des enjeux de destination et des pistes de collaboration.' },
    ],
    body: 'Pour les hôtels et agences intéressés : la prochaine action proposée est une réunion de cadrage afin de choisir un cas d’usage et préciser les conditions d’un éventuel pilote.',
    statusNote: 'Contacts et partenariats à établir après l’événement.',
  },
  {
    id: 34,
    chapter: 'Lancement officiel',
    kind: 'launch',
    kicker: '15 DÉCEMBRE 2026 · AGADIR, MAROC',
    title: 'SAFARONE IS OFFICIALLY LAUNCHED.',
    subtitle: 'Le lancement est un succès.',
    slogan: 'BUILT IN MOROCCO. DESIGNED FOR THE WORLD.',
    body: 'Cité de l’Innovation Souss-Massa · HK Solutions SARL',
  },
];

const slidesById = new Map(originalSlides.map((slide) => [slide.id, slide]));
const slideOrder = [1, 2, 3, 6, 7, 18, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 4, 33, 5, 34];
export const slides = slideOrder.map((id) => {
  const slide = slidesById.get(id);
  if (!slide) throw new Error(`Missing presentation slide ${id}`);
  return slide;
});

export const sourceLinks = [
  {
    label: 'Ministère du Tourisme · Chiffres clés',
    url: 'https://mtaess.gov.ma/fr/key-figures/',
  },
  {
    label: 'Ministère du Tourisme · Feuille de route',
    url: 'https://mtaess.gov.ma/fr/tourisme/feuille-de-route/',
  },
  {
    label: 'Ministère du Tourisme · Arrivées touristiques 2025',
    url: 'https://mtaess.gov.ma/fr/tourisme-le-maroc-atteint-un-seuil-historique-de-pres-de-20-millions-de-touristes-en-2025',
  },
  {
    label: 'FIFA · Pays hôtes de 2030',
    url: 'https://www.fifa.com/en/tournaments/mens/worldcup/2030',
  },
  {
    label: 'FIFA · Visites de sélection des villes candidates',
    url: 'https://inside.fifa.com/fr/tournament-organisation/news/coupe-monde-2030-selection-visites-maroc-portugal-espagne',
  },
];
