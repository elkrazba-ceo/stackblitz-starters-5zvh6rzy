# SafarOne Launch Experience

A French-language cinematic launch presentation for SafarOne, with 34 slides, synchronized audience/presenter views, speaker scripts, Three.js scenes and a final rocket launch sequence.

## Run

- `pnpm install`
- `pnpm --filter @workspace/safarone-launch run dev`
- `pnpm --filter @workspace/safarone-launch run typecheck`
- `pnpm --filter @workspace/safarone-launch run build`

## Main application

`artifacts/safarone-launch/`

- `src/data/slides.ts` — slide content and presentation order. Slide IDs remain stable; `slideOrder` controls sequence.
- `src/data/speakerScripts.ts` — private speaker scripts keyed by stable slide ID.
- `src/components/LaunchPresentation.tsx` — public presentation.
- `src/pages/PresenterConsole.tsx` — private presenter view and controls.
- `src/components/ImmersiveScene.tsx` — ambient/product/research 3D scenes, mapped by stable slide ID.
- `src/components/RocketScene.tsx` — final launch animation.

## Important decisions

- Preserve all 34 original slide IDs and content; reorder through `slideOrder`, not by renumbering IDs.
- Tribute slide ID 5 is second-to-last; launch slide ID 34 is the final slide.
- Three.js scenes are selected by stable slide IDs, not array indexes.
- Hotel QR access is presented as a proposed model, not an existing deployment.
- Partner relationships and impact are described as opportunities to validate, not confirmed outcomes.
- Reduced-motion mode renders meaningful static states and updates when launch phases change.

## Build note

The project is part of the pnpm workspace under `artifacts/safarone-launch`. Run installation from the repository root so workspace dependencies and aliases resolve correctly.
